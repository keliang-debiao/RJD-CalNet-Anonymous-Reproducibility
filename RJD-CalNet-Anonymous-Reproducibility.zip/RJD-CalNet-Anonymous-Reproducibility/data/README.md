# Dataset placement and preparation

## Public sources

| Role | Dataset | Kaggle identifier | Analytic records | Input | Targets |
|---|---|---|---:|---|---|
| Development and internal validation | DEAM | `imsparsh/deam-mediaeval-dataset-emotional-analysis-in-music` | 1,802 songs | 6,373 locally extracted IS13_ComParE functionals | Mean valence, mean arousal, and listener SD for both dimensions |
| Frozen external validation | PMEmo | `deshadsithsara/pmemo-2018-dataset` | 767 complete records | 6,373 released IS13_ComParE functionals | Mean valence, mean arousal, and listener SD for both dimensions |

The original PMEmo corpus contains 794 songs. The manuscript analysis uses the 767 complete aligned records in the processed Kaggle table and does not assign the 27-record difference to an unverified cause.

## Required local layout

```text
data/
  raw/
    deam/
    pmemo/
  processed/
```

Dataset archives, audio, labels, and prepared tables are intentionally excluded from version control.

## DEAM feature extraction

Use the openSMILE configuration named `IS13_ComParE.conf` and preserve the output column names. The local command must yield one row per audited song and 6,373 numeric functionals. Keep the openSMILE version, configuration checksum, audio identifier, and audio checksum in the extraction manifest.

```bash
python scripts/extract_deam_features.py \
  --audio-root data/raw/deam/audio \
  --config data/raw/deam/IS13_ComParE.conf \
  --output data/raw/deam/deam_is13_compare.csv
```

The study maps original DEAM labels from 1–9 to 0–1 as follows:

```text
normalized_mean = (original_mean - 1) / 8
normalized_listener_sd = original_listener_sd / 8
```

## PMEmo handling

Do not re-extract PMEmo features. Read the released processed functionals, retain the 767 complete aligned rows, and reorder columns against the DEAM-derived feature manifest. A missing feature is an error unless an explicitly audited alias is recorded in `feature_manifest.json`.

## Required prepared columns

Each prepared table contains:

```text
song_id
source_group
valence_mean
arousal_mean
valence_sd
arousal_sd
feat__<openSMILE feature name> ...
```

DEAM additionally retains normalized artist/title fields and audio hashes when available. PMEmo metadata may be stored for auditing but is not used by the predictive model.

## Leakage safeguards

Preparation determines identifiers, immutable duplicate/source groups, and the feature schema. Winsorization, median imputation, robust scaling, learned representations, calibration, and model fitting occur later inside the appropriate training partition. The PMEmo labels are read only by frozen evaluation code.

## License boundary

The Kaggle mirror metadata lists CC BY-NC-SA 4.0 for both releases. Original audio, annotations, and mirror files remain subject to the terms attached to each source. This repository contains code and result summaries only.
