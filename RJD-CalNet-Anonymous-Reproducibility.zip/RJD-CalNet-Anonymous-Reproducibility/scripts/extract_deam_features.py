#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import opensmile
import pandas as pd
from tqdm import tqdm


AUDIO_SUFFIXES = {".wav", ".mp3", ".flac", ".ogg"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description="Extract locked DEAM openSMILE functionals")
    parser.add_argument("--audio-root", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--output", default="data/raw/deam/deam_is13_compare.csv")
    parser.add_argument("--manifest", default="data/raw/deam/deam_is13_compare_manifest.json")
    args = parser.parse_args()
    audio_root = Path(args.audio_root)
    config_path = Path(args.config)
    files = sorted(
        path for path in audio_root.rglob("*") if path.is_file() and path.suffix.lower() in AUDIO_SUFFIXES
    )
    if not files:
        raise FileNotFoundError(f"No supported audio files found under {audio_root}")
    smile = opensmile.Smile(
        feature_set=str(config_path),
        feature_level=opensmile.FeatureLevel.Functionals,
    )
    rows = []
    audio_records = []
    expected_columns = None
    for path in tqdm(files, desc="openSMILE"):
        frame = smile.process_file(str(path))
        if len(frame) != 1:
            raise ValueError(f"Expected one functional row for {path}; received {len(frame)}")
        values = frame.reset_index(drop=True)
        columns = values.columns.astype(str).tolist()
        if expected_columns is None:
            expected_columns = columns
            if len(expected_columns) != 6373:
                raise ValueError(
                    f"The locked configuration must produce 6373 functionals; received {len(expected_columns)}"
                )
        elif columns != expected_columns:
            raise ValueError(f"Feature-column order changed while processing {path}")
        record = {"song_id": path.stem}
        record.update(values.iloc[0].to_dict())
        rows.append(record)
        audio_records.append(
            {
                "song_id": path.stem,
                "relative_path": str(path.relative_to(audio_root)),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
        )
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output, index=False)
    manifest = {
        "opensmile_version": opensmile.__version__,
        "configuration": config_path.name,
        "configuration_sha256": sha256(config_path),
        "audio_count": len(files),
        "feature_count": len(expected_columns),
        "audio": audio_records,
    }
    manifest_path = Path(args.manifest)
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(f"rows={len(rows)} features={len(expected_columns)} output={output}")


if __name__ == "__main__":
    main()

