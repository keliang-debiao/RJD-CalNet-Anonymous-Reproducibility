#!/usr/bin/env python3
from __future__ import annotations

import numpy as np

from rjd_calnet.calibration import conformal_quantile, fit_conformal_radii
from rjd_calnet.data.preprocessing import RobustFoldPreprocessor
from rjd_calnet.data.splits import grouped_outer_splits
from rjd_calnet.ensemble import moment_match_student_t


def main() -> None:
    training = np.array([[0.0, 1.0], [1.0, 3.0], [2.0, np.nan], [100.0, 5.0]])
    held_out = np.array([[1000.0, np.nan]])
    processor = RobustFoldPreprocessor().fit(training)
    state = processor.state_dict()
    transformed, missing = processor.transform(held_out)
    assert transformed.shape == (1, 2)
    assert missing[0, 1] == 1.0
    restored = RobustFoldPreprocessor.from_state_dict(state)
    np.testing.assert_allclose(processor.transform(training)[0], restored.transform(training)[0])

    groups = np.repeat(np.arange(50), 2)
    splits = grouped_outer_splits(groups, 5, seed=2026)
    all_test = []
    for split in splits:
        parts = [
            split.fit_indices,
            split.temperature_indices,
            split.conformal_indices,
            split.test_indices,
        ]
        group_sets = [set(groups[index]) for index in parts]
        for left in range(len(group_sets)):
            for right in range(left + 1, len(group_sets)):
                assert group_sets[left].isdisjoint(group_sets[right])
        all_test.extend(split.test_indices.tolist())
    assert sorted(all_test) == list(range(len(groups)))

    assert conformal_quantile(np.arange(1, 11, dtype=float), 0.20) == 9.0
    target = np.array([[0.4, 0.5], [0.6, 0.7], [0.3, 0.2]])
    location = np.array([[0.42, 0.48], [0.58, 0.68], [0.31, 0.24]])
    scale = np.repeat(np.eye(2)[None, :, :] * 0.02, 3, axis=0)
    radii = fit_conformal_radii(target, location, scale, 1.2, [0.80, 0.90])
    assert radii["0.90"] >= radii["0.80"]

    members = []
    for shift in (-0.01, 0.0, 0.01):
        members.append(
            {
                "location": np.array([[0.5 + shift, 0.6 - shift]]),
                "scale": np.array([[[0.02, 0.004], [0.004, 0.03]]]),
                "degrees_of_freedom": np.array([6.0]),
                "listener_disagreement": np.array([[0.1, 0.12]]),
            }
        )
    matched = moment_match_student_t(members)
    assert np.linalg.eigvalsh(matched["scale"]).min() > 0.0
    print("static_contracts=passed")


if __name__ == "__main__":
    main()

