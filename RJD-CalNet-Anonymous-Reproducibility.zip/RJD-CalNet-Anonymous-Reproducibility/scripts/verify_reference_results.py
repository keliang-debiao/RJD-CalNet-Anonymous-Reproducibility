#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd


def close(left, right, tolerance=1.0e-12):
    if not np.isclose(float(left), float(right), atol=tolerance, rtol=0.0):
        raise AssertionError(f"Value mismatch: {left} != {right}")


def main() -> None:
    root = Path(__file__).resolve().parents[1] / "reference_results"
    internal = pd.read_csv(root / "table_05_internal_cv.csv")
    mean_row = internal.loc[internal["fold"].astype(str) == "mean"].iloc[0]
    close(mean_row["med"], 0.112)
    close(mean_row["joint_nll"], -1.421)
    close(mean_row["coverage_90"], 0.892)

    baselines = pd.read_csv(root / "table_06_baselines_deam.csv")
    rjd = baselines.loc[baselines["model"] == "RJD-CalNet"].iloc[0]
    close(rjd["med_mean"], mean_row["med"])
    close(rjd["ccc_v"], mean_row["ccc_v"])
    close(rjd["ccc_a"], mean_row["ccc_a"])

    external = pd.read_csv(root / "table_07_external_pmemo.csv")
    rjd_external = external.loc[external["model"] == "RJD-CalNet"].iloc[0]
    close(rjd_external["med"], 0.139)
    close(rjd_external["coverage_90"], 0.876)

    ablations = pd.read_csv(root / "table_09_ablations.csv")
    full = ablations.loc[ablations["configuration"] == "Full RJD-CalNet"].iloc[0]
    close(full["deam_med"], rjd["med_mean"])
    close(full["pmemo_med"], rjd_external["med"])

    calibration = pd.read_csv(root / "table_10_calibration.csv")
    deam_full = calibration.loc[
        (calibration["dataset"] == "DEAM") & (calibration["method"] == "TS-FSCC")
    ].iloc[0]
    pmemo_full = calibration.loc[
        (calibration["dataset"] == "PMEmo")
        & (calibration["method"] == "Frozen TS-FSCC")
    ].iloc[0]
    close(deam_full["coverage_90"], mean_row["coverage_90"])
    close(pmemo_full["coverage_90"], rjd_external["coverage_90"])
    close(full["coverage_error_90"], deam_full["coverage_error"])

    disagreement = pd.read_csv(
        root / "table_13_disagreement_interpretability_efficiency.csv"
    )
    parameters = disagreement.loc[
        (disagreement["analysis"] == "Efficiency")
        & (disagreement["measure"] == "Parameters million"),
        "value",
    ].iloc[0]
    close(parameters, 1.840)
    print("reference_result_checks=passed")


if __name__ == "__main__":
    main()

