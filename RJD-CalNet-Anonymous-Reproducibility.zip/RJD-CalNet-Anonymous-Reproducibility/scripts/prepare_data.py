#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json

from rjd_calnet.preparation import prepare_datasets


def main() -> None:
    parser = argparse.ArgumentParser(description="Prepare the locked DEAM and PMEmo tables")
    parser.add_argument("--deam-features", required=True)
    parser.add_argument("--deam-labels", required=True)
    parser.add_argument("--pmemo-table", required=True)
    parser.add_argument("--output-dir", default="data/processed")
    parser.add_argument("--schema", default="configs/data_schema.yaml")
    args = parser.parse_args()
    audit = prepare_datasets(
        args.deam_features,
        args.deam_labels,
        args.pmemo_table,
        args.output_dir,
        args.schema,
    )
    print(json.dumps(audit, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

