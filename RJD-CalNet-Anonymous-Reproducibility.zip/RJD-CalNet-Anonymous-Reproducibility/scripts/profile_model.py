#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import time

import numpy as np
import torch

from rjd_calnet.config import load_yaml
from rjd_calnet.models import RJDCalNet
from rjd_calnet.utils import read_json, resolve_device


def main() -> None:
    parser = argparse.ArgumentParser(description="Profile the frozen RJD-CalNet forward path")
    parser.add_argument("--config", default="configs/locked.yaml")
    parser.add_argument("--repeats", type=int, default=1000)
    args = parser.parse_args()
    config = load_yaml(args.config)
    manifest = read_json(config["data"]["feature_manifest"])
    device = resolve_device(config["run"]["device"])
    model = RJDCalNet(manifest, config).to(device).eval()
    features = len(manifest["features"])
    x = torch.zeros(1, features, device=device)
    missing = torch.zeros_like(x)
    with torch.inference_mode():
        for _ in range(100):
            model(x, missing)
        if device.type == "cuda":
            torch.cuda.reset_peak_memory_stats(device)
            torch.cuda.synchronize(device)
        start = time.perf_counter()
        for _ in range(args.repeats):
            model(x, missing)
        if device.type == "cuda":
            torch.cuda.synchronize(device)
        elapsed = time.perf_counter() - start
    with torch.profiler.profile(with_flops=True) as profile:
        with torch.inference_mode():
            model(x, missing)
    flops = int(sum(event.flops for event in profile.key_averages() if event.flops))
    result = {
        "trainable_parameters_single_member": int(
            sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)
        ),
        "trainable_parameters_three_member_ensemble": int(
            3 * sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)
        ),
        "flops_per_song": flops,
        "latency_ms_per_song": 1000.0 * elapsed / args.repeats,
        "peak_gpu_memory_gb": (
            torch.cuda.max_memory_allocated(device) / 1.0e9 if device.type == "cuda" else None
        ),
        "repeats": args.repeats,
        "device_type": device.type,
    }
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

