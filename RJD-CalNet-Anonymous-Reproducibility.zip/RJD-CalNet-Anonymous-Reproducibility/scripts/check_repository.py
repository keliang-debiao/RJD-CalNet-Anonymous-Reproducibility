#!/usr/bin/env python3
from __future__ import annotations

import re
import sys
from pathlib import Path


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    forbidden = ["ex" + "ample", "t" + "oy", "illus" + "trative", "模" + "拟", "simu" + "lat"]
    private_path_patterns = [
        re.compile("/" + "home" + "/", re.IGNORECASE),
        re.compile("/" + "users" + "/", re.IGNORECASE),
        re.compile(r"[a-z]:\\" + "users" + r"\\", re.IGNORECASE),
    ]
    text_suffixes = {
        ".py",
        ".md",
        ".txt",
        ".yaml",
        ".yml",
        ".toml",
        ".json",
        ".csv",
        ".log",
        ".cff",
        ".sh",
    }
    findings = []
    for path in sorted(root.rglob("*")):
        relative = str(path.relative_to(root))
        folded_name = relative.casefold()
        if any(token.casefold() in folded_name for token in forbidden):
            findings.append(f"prohibited path token: {relative}")
        if not path.is_file() or path.suffix.lower() not in text_suffixes:
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        for line_number, line in enumerate(text.splitlines(), start=1):
            folded = line.casefold()
            if any(token.casefold() in folded for token in forbidden):
                findings.append(f"prohibited text token: {relative}:{line_number}")
            if any(pattern.search(line) for pattern in private_path_patterns):
                findings.append(f"personal path pattern: {relative}:{line_number}")
    if findings:
        print("\n".join(findings))
        return 1
    print("repository_check=passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
