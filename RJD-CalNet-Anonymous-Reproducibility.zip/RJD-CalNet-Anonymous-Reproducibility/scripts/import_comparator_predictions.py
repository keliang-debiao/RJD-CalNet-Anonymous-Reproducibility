#!/usr/bin/env python3
from __future__ import annotations

import argparse
import shutil
from pathlib import Path

import pandas as pd


REQUIRED = {
    "song_id",
    "target_valence",
    "target_arousal",
    "predicted_valence",
    "predicted_arousal",
}


def main() -> None:
    parser = argparse.ArgumentParser(description="Validate and register comparator predictions")
    parser.add_argument("--input", required=True)
    parser.add_argument("--dataset", required=True, choices=["deam", "pmemo"])
    parser.add_argument("--model", required=True)
    parser.add_argument("--output-dir", default="outputs/baselines")
    args = parser.parse_args()
    source = Path(args.input)
    frame = pd.read_parquet(source)
    missing = REQUIRED.difference(frame.columns)
    if missing:
        raise ValueError(f"Prediction table is missing required columns: {sorted(missing)}")
    if frame["song_id"].astype(str).duplicated().any():
        raise ValueError("Prediction table contains duplicate song identifiers")
    if not frame[list(REQUIRED - {"song_id"})].notna().all().all():
        raise ValueError("Prediction table contains missing numeric values")
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    target = output / f"predictions_{args.dataset}_{args.model.lower()}.parquet"
    shutil.copy2(source, target)
    print(f"registered={target} rows={len(frame)}")


if __name__ == "__main__":
    main()

