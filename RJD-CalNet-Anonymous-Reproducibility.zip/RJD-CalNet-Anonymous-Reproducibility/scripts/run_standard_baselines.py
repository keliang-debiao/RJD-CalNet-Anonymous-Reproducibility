#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json

from rjd_calnet.standard_baselines import run_standard_baselines


def main() -> None:
    parser = argparse.ArgumentParser(description="Run nested standard baseline evaluations")
    parser.add_argument("--config", default="configs/baselines/all.yaml")
    parser.add_argument(
        "--models",
        nargs="+",
        default=["ridge", "random_forest", "xgboost", "mlp", "tabnet"],
        choices=["ridge", "random_forest", "xgboost", "mlp", "tabnet"],
    )
    args = parser.parse_args()
    result = run_standard_baselines(args.config, args.models)
    print(json.dumps(result, indent=2, sort_keys=True, default=str))


if __name__ == "__main__":
    main()

