#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json

from rjd_calnet.robustness import run_robustness_suite


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the prespecified RJD-CalNet robustness suite")
    parser.add_argument("--config", default="configs/robustness/all.yaml")
    args = parser.parse_args()
    print(json.dumps(run_robustness_suite(args.config), indent=2, sort_keys=True, default=str))


if __name__ == "__main__":
    main()

