#!/usr/bin/env bash
set -euo pipefail

python scripts/check_repository.py
python -m rjd_calnet.cli audit --config configs/locked.yaml
python -m rjd_calnet.cli cross-validate --config configs/locked.yaml
python -m rjd_calnet.cli external --config configs/locked.yaml
python -m rjd_calnet.cli summarize --run-dir outputs/locked_run
