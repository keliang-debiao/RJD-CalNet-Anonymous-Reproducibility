#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
from pathlib import Path


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    output = root / "SOURCE_MANIFEST.json"
    excluded_parts = {".git", "__pycache__", ".pytest_cache", "outputs", "raw", "processed"}
    records = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path == output:
            continue
        if any(part in excluded_parts for part in path.parts):
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        records.append(
            {
                "path": str(path.relative_to(root)),
                "bytes": path.stat().st_size,
                "sha256": digest,
            }
        )
    payload = {
        "schema_version": 1,
        "file_count": len(records),
        "files": records,
    }
    output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"source_manifest_files={len(records)}")


if __name__ == "__main__":
    main()

