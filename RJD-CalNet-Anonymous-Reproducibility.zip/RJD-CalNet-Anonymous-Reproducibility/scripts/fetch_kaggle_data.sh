#!/usr/bin/env bash
set -euo pipefail

mkdir -p data/raw/deam data/raw/pmemo
kaggle datasets download \
  -d imsparsh/deam-mediaeval-dataset-emotional-analysis-in-music \
  -p data/raw/deam \
  --unzip
kaggle datasets download \
  -d deshadsithsara/pmemo-2018-dataset \
  -p data/raw/pmemo \
  --unzip

find data/raw/deam data/raw/pmemo -type f -print | sort

