# Reference result records

These records are concise transcriptions of the verified results reported in the manuscript. Their purpose is to define expected field names, decimal precision, fold order, and cross-file consistency checks.

They are not execution traces produced during package assembly. A completed run writes independent timestamped logs and prediction files under `outputs/`. Reviewers should use those newly generated files when verifying a local run.

Source mapping:

- `deam_cv.log`: Tables 5 and 6
- `pmemo_external.log`: Table 7
- `ablations_calibration.log`: Tables 9 to 12
- `efficiency.log`: Table 13
- `locked_protocol.log`: locked data and evaluation contract

