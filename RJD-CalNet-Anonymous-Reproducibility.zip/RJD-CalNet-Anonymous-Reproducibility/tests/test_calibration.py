import numpy as np

from rjd_calnet.calibration import conformal_quantile, coverage_and_area, fit_conformal_radii


def test_conformal_quantile_uses_conservative_rank():
    scores = np.arange(1, 11, dtype=float)
    assert conformal_quantile(scores, alpha=0.20) == 9.0


def test_joint_region_outputs_are_finite():
    target = np.array([[0.4, 0.5], [0.6, 0.7], [0.3, 0.2]])
    location = np.array([[0.42, 0.48], [0.58, 0.68], [0.31, 0.24]])
    scale = np.repeat(np.eye(2)[None, :, :] * 0.02, 3, axis=0)
    radii = fit_conformal_radii(target, location, scale, 1.2, [0.80, 0.90])
    coverage, area = coverage_and_area(target, location, scale, 1.2, radii["0.90"])
    assert 0.0 <= coverage <= 1.0
    assert area > 0.0

