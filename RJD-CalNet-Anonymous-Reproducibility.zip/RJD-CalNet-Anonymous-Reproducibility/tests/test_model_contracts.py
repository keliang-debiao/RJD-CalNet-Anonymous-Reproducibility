import pytest

torch = pytest.importorskip("torch")

from rjd_calnet.models import RJDCalNet


def _manifest():
    features = []
    for group in range(7):
        for offset in range(3):
            features.append(
                {
                    "column": f"feat__g{group}_f{offset}",
                    "group": str(group),
                    "descriptor": f"d{group}",
                    "functional": f"f{offset}",
                    "group_id": group,
                    "descriptor_id": group,
                    "functional_id": offset,
                }
            )
    return {
        "group_order": [str(index) for index in range(7)],
        "descriptor_vocab": {str(index): index for index in range(7)},
        "functional_vocab": {str(index): index for index in range(3)},
        "features": features,
    }


def _config():
    return {
        "model": {
            "d_model": 16,
            "n_layers": 2,
            "n_heads": 4,
            "n_experts": 3,
            "local_expansion": 2,
            "low_rank_dim": 8,
            "router_hidden": 16,
            "reliability_hidden": 16,
            "dropout": 0.0,
            "reliability_pool_strength": 1.0,
            "minimum_df": 2.05,
            "disagreement_ceiling": 0.5,
        }
    }


def test_forward_contract_and_positive_definite_scale():
    model = RJDCalNet(_manifest(), _config())
    x = torch.randn(5, 21)
    missing = torch.zeros_like(x)
    output = model(x, missing)
    assert output["location"].shape == (5, 2)
    assert output["scale"].shape == (5, 2, 2)
    assert output["listener_disagreement"].shape == (5, 2)
    assert output["routing"].shape == (5, 2, 7, 3)
    assert torch.all(torch.linalg.eigvalsh(output["scale"]) > 0)
    assert torch.all(output["degrees_of_freedom"] > 2)
    assert torch.all((output["location"] >= 0) & (output["location"] <= 1))
    assert torch.all(
        (output["listener_disagreement"] >= 0)
        & (output["listener_disagreement"] <= 0.5)
    )

