import numpy as np

from rjd_calnet.data.splits import grouped_outer_splits


def test_source_groups_never_cross_boundaries():
    groups = np.repeat(np.arange(50), 2)
    splits = grouped_outer_splits(groups, n_splits=5, seed=2026)
    seen_test = []
    for split in splits:
        partitions = [
            split.fit_indices,
            split.temperature_indices,
            split.conformal_indices,
            split.test_indices,
        ]
        group_sets = [set(groups[index]) for index in partitions]
        for left in range(len(group_sets)):
            for right in range(left + 1, len(group_sets)):
                assert group_sets[left].isdisjoint(group_sets[right])
        seen_test.extend(split.test_indices.tolist())
    assert sorted(seen_test) == list(range(len(groups)))

