import numpy as np

from rjd_calnet.data.preprocessing import RobustFoldPreprocessor


def test_training_statistics_are_reused_without_refit():
    training = np.array([[0.0, 1.0], [1.0, 3.0], [2.0, np.nan], [100.0, 5.0]])
    held_out = np.array([[1000.0, np.nan]])
    processor = RobustFoldPreprocessor().fit(training)
    median_before = processor.median_.copy()
    transformed, missing = processor.transform(held_out)
    np.testing.assert_allclose(processor.median_, median_before)
    assert transformed.shape == (1, 2)
    assert missing[0, 1] == 1.0


def test_state_round_trip():
    values = np.arange(24, dtype=float).reshape(8, 3)
    fitted = RobustFoldPreprocessor().fit(values)
    restored = RobustFoldPreprocessor.from_state_dict(fitted.state_dict())
    left = fitted.transform(values)[0]
    right = restored.transform(values)[0]
    np.testing.assert_allclose(left, right)

