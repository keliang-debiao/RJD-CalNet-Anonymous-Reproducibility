import numpy as np

from rjd_calnet.ensemble import moment_match_student_t


def test_moment_matched_scale_is_positive_definite():
    members = []
    for shift in (-0.01, 0.0, 0.01):
        members.append(
            {
                "location": np.array([[0.5 + shift, 0.6 - shift]]),
                "scale": np.array([[[0.02, 0.004], [0.004, 0.03]]]),
                "degrees_of_freedom": np.array([6.0]),
                "listener_disagreement": np.array([[0.1, 0.12]]),
            }
        )
    result = moment_match_student_t(members)
    assert np.linalg.eigvalsh(result["scale"])[0].min() > 0.0
    np.testing.assert_allclose(result["location"], [[0.5, 0.6]])

