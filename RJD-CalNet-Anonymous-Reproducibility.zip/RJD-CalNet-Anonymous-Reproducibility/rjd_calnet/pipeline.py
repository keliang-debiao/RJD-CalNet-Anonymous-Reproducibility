from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import GroupShuffleSplit

from .calibration import coverage_and_area, fit_conformal_radii, fit_temperature
from .config import save_yaml, validate_locked_config
from .data.dataset import TorchArrayDataset, load_prepared_table
from .data.preprocessing import RobustFoldPreprocessor
from .data.splits import OuterSplit, grouped_outer_splits
from .engine import fit_fixed_epochs, predict, select_epoch
from .ensemble import moment_match_student_t
from .metrics import disagreement_metrics, distribution_metrics, point_metrics
from .models import RJDCalNet
from .utils import environment_inventory, read_json, resolve_device, source_tree_hash, write_json


def _audit_bundle(bundle, expected_rows: int, expected_features: int, name: str) -> None:
    if len(bundle.x) != expected_rows:
        raise ValueError(f"{name} row count {len(bundle.x)} does not equal {expected_rows}")
    if bundle.x.shape[1] != expected_features:
        raise ValueError(
            f"{name} feature count {bundle.x.shape[1]} does not equal {expected_features}"
        )
    if not np.isfinite(bundle.y).all() or not np.isfinite(bundle.disagreement).all():
        raise ValueError(f"{name} contains non-finite targets")
    if np.any(bundle.y < 0.0) or np.any(bundle.y > 1.0):
        raise ValueError(f"{name} affect means are outside the unit interval")
    if np.any(bundle.disagreement < 0.0) or np.any(bundle.disagreement > 0.5):
        raise ValueError(f"{name} listener disagreement is outside the feasible range")


def audit_data(config: dict) -> dict:
    data = config["data"]
    deam = load_prepared_table(data["deam_table"], data["feature_prefix"])
    pmemo = load_prepared_table(data["pmemo_table"], data["feature_prefix"])
    _audit_bundle(deam, data["expected_deam_rows"], data["expected_features"], "DEAM")
    _audit_bundle(pmemo, data["expected_pmemo_rows"], data["expected_features"], "PMEmo")
    manifest = read_json(data["feature_manifest"])
    if len(manifest["features"]) != data["expected_features"]:
        raise ValueError("Feature manifest length differs from the locked feature count")
    if len(np.unique(deam.song_ids)) != len(deam.song_ids):
        raise ValueError("DEAM prepared identifiers are not unique")
    if len(np.unique(pmemo.song_ids)) != len(pmemo.song_ids):
        raise ValueError("PMEmo prepared identifiers are not unique")
    return {
        "deam_rows": len(deam.x),
        "pmemo_rows": len(pmemo.x),
        "feature_count": deam.x.shape[1],
        "deam_groups": len(np.unique(deam.groups)),
        "deam_nonfinite_features": int((~np.isfinite(deam.x)).sum()),
        "pmemo_nonfinite_features": int((~np.isfinite(pmemo.x)).sum()),
    }


def _selection_split(indices: np.ndarray, groups: np.ndarray, seed: int):
    splitter = GroupShuffleSplit(n_splits=1, test_size=0.12, random_state=seed)
    train_local, validation_local = next(splitter.split(indices, groups=groups[indices]))
    train_indices = indices[train_local]
    validation_indices = indices[validation_local]
    if set(groups[train_indices]).intersection(set(groups[validation_indices])):
        raise AssertionError("Epoch-selection groups overlap")
    return train_indices, validation_indices


def _dataset(bundle, indices, preprocessor):
    x, missing = preprocessor.transform(bundle.x[indices])
    return TorchArrayDataset(
        x,
        missing,
        bundle.y[indices],
        bundle.disagreement[indices],
        indices=indices,
    )


def _fit_members(
    bundle,
    fit_indices: np.ndarray,
    prediction_partitions: dict[str, tuple],
    manifest: dict,
    config: dict,
    output_dir: Path,
    fold_label: str,
) -> tuple[dict[str, dict], RobustFoldPreprocessor, list[int]]:
    import torch

    device = resolve_device(config["run"]["device"])
    selection_train, selection_validation = _selection_split(
        fit_indices, bundle.groups, config["cross_validation"]["splitter_seed"]
    )
    selection_preprocessor = RobustFoldPreprocessor(
        config["preprocessing"]["lower_quantile"],
        config["preprocessing"]["upper_quantile"],
        config["preprocessing"]["epsilon"],
    ).fit(bundle.x[selection_train])
    selection_train_dataset = _dataset(bundle, selection_train, selection_preprocessor)
    selection_validation_dataset = _dataset(bundle, selection_validation, selection_preprocessor)
    final_preprocessor = RobustFoldPreprocessor(
        config["preprocessing"]["lower_quantile"],
        config["preprocessing"]["upper_quantile"],
        config["preprocessing"]["epsilon"],
    ).fit(bundle.x[fit_indices])
    final_fit_dataset = _dataset(bundle, fit_indices, final_preprocessor)
    member_predictions = {name: [] for name in prediction_partitions}
    selected_epochs = []
    histories = {}
    output_dir.mkdir(parents=True, exist_ok=True)
    for seed in config["training"]["seeds"]:
        selection_model = RJDCalNet(manifest, config)
        best_epoch, selection_history = select_epoch(
            selection_model,
            selection_train_dataset,
            selection_validation_dataset,
            config,
            device,
            seed,
        )
        selected_epochs.append(best_epoch)
        final_model = RJDCalNet(manifest, config)
        fit_history = fit_fixed_epochs(
            final_model, final_fit_dataset, config, device, seed, best_epoch
        )
        checkpoint = output_dir / f"{fold_label}_seed_{seed}.pt"
        torch.save(
            {
                "model_state": final_model.state_dict(),
                "seed": seed,
                "selected_epoch": best_epoch,
                "config_name": config["run"]["name"],
            },
            checkpoint,
        )
        histories[str(seed)] = {"selection": selection_history, "fit": fit_history}
        for name, (partition_bundle, indices) in prediction_partitions.items():
            dataset = _dataset(partition_bundle, indices, final_preprocessor)
            member_predictions[name].append(
                predict(final_model, dataset, config["training"]["batch_size"], device)
            )
        del selection_model, final_model
        if device.type == "cuda":
            torch.cuda.empty_cache()
    write_json(histories, output_dir / f"{fold_label}_histories.json")
    return (
        {name: moment_match_student_t(members) | {
            "reliability": np.stack([m["reliability"] for m in members]).mean(axis=0),
            "pooling_weights": np.stack([m["pooling_weights"] for m in members]).mean(axis=0),
            "routing": np.stack([m["routing"] for m in members]).mean(axis=0),
        } for name, members in member_predictions.items()},
        final_preprocessor,
        selected_epochs,
    )


def _prediction_frame(song_ids, target, disagreement, prediction, fold=None):
    frame = pd.DataFrame(
        {
            "song_id": song_ids,
            "target_valence": target[:, 0],
            "target_arousal": target[:, 1],
            "target_valence_sd": disagreement[:, 0],
            "target_arousal_sd": disagreement[:, 1],
            "predicted_valence": prediction["location"][:, 0],
            "predicted_arousal": prediction["location"][:, 1],
            "predicted_valence_sd": prediction["listener_disagreement"][:, 0],
            "predicted_arousal_sd": prediction["listener_disagreement"][:, 1],
            "degrees_of_freedom": prediction["degrees_of_freedom"],
            "reliability_mean": prediction["reliability"].mean(axis=1),
        }
    )
    frame["scale_00"] = prediction["scale"][:, 0, 0]
    frame["scale_01"] = prediction["scale"][:, 0, 1]
    frame["scale_11"] = prediction["scale"][:, 1, 1]
    if fold is not None:
        frame["fold"] = fold
    return frame


def _evaluate(target, disagreement, prediction, config):
    values = point_metrics(target, prediction["location"])
    values.update(
        distribution_metrics(
            target, prediction, draws=config["evaluation"]["predictive_draws"]
        )
    )
    values["disagreement"] = disagreement_metrics(
        disagreement, prediction["listener_disagreement"]
    )
    return values


def run_cross_validation(config: dict, repository_root: Path) -> dict:
    validate_locked_config(config)
    output_dir = Path(config["run"]["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    save_yaml(config, output_dir / "resolved_config.yaml")
    write_json(environment_inventory(), output_dir / "environment.json")
    write_json({"source_tree_sha256": source_tree_hash(repository_root)}, output_dir / "source_hash.json")
    audit = audit_data(config)
    write_json(audit, output_dir / "data_audit.json")
    data_config = config["data"]
    deam = load_prepared_table(data_config["deam_table"], data_config["feature_prefix"])
    manifest = read_json(data_config["feature_manifest"])
    splits = grouped_outer_splits(
        deam.groups,
        config["cross_validation"]["outer_folds"],
        config["cross_validation"]["calibration_fraction"],
        config["cross_validation"]["temperature_fraction"],
        config["cross_validation"]["splitter_seed"],
    )
    fold_records = []
    prediction_frames = []
    split_rows = []
    for split in splits:
        start = time.perf_counter()
        partitions = {
            "temperature": (deam, split.temperature_indices),
            "conformal": (deam, split.conformal_indices),
            "test": (deam, split.test_indices),
        }
        predictions, preprocessor, epochs = _fit_members(
            deam,
            split.fit_indices,
            partitions,
            manifest,
            config,
            output_dir / "checkpoints",
            f"fold_{split.fold}",
        )
        temperature = fit_temperature(
            deam.y[split.temperature_indices],
            predictions["temperature"]["location"],
            predictions["temperature"]["scale"],
            predictions["temperature"]["degrees_of_freedom"],
            config["calibration"]["temperature_lower_bound"],
            config["calibration"]["temperature_upper_bound"],
            config["calibration"]["temperature_grid_size"],
        )
        radii = fit_conformal_radii(
            deam.y[split.conformal_indices],
            predictions["conformal"]["location"],
            predictions["conformal"]["scale"],
            temperature,
            config["calibration"]["nominal_levels"],
        )
        test_prediction = predictions["test"]
        raw_test_scale = test_prediction["scale"].copy()
        test_prediction["scale"] = raw_test_scale * temperature
        metrics = _evaluate(
            deam.y[split.test_indices], deam.disagreement[split.test_indices], test_prediction, config
        )
        coverage, area = coverage_and_area(
            deam.y[split.test_indices],
            test_prediction["location"],
            raw_test_scale,
            temperature,
            radii["0.90"],
        )
        metrics.update(
            fold=split.fold,
            temperature=temperature,
            conformal_radii=radii,
            coverage_90=coverage,
            ellipse_area_90=area,
            selected_epochs=epochs,
            elapsed_seconds=time.perf_counter() - start,
        )
        fold_records.append(metrics)
        prediction_frames.append(
            _prediction_frame(
                deam.song_ids[split.test_indices],
                deam.y[split.test_indices],
                deam.disagreement[split.test_indices],
                test_prediction,
                fold=split.fold,
            )
        )
        for partition_name, indices in (
            ("fit", split.fit_indices),
            ("temperature", split.temperature_indices),
            ("conformal", split.conformal_indices),
            ("test", split.test_indices),
        ):
            split_rows.extend(
                {
                    "fold": split.fold,
                    "partition": partition_name,
                    "song_id": deam.song_ids[index],
                    "source_group": deam.groups[index],
                }
                for index in indices
            )
        write_json(preprocessor.state_dict(), output_dir / f"preprocessor_fold_{split.fold}.json")
    pd.DataFrame(split_rows).to_csv(output_dir / "fold_manifest.csv", index=False)
    oof = pd.concat(prediction_frames, ignore_index=True).sort_values("song_id")
    oof.to_parquet(output_dir / "predictions_deam_oof.parquet", index=False)
    write_json(fold_records, output_dir / "metrics_internal_folds.json")
    summary = {
        "folds": len(fold_records),
        "med_mean": float(np.mean([item["med"] for item in fold_records])),
        "med_sd": float(np.std([item["med"] for item in fold_records], ddof=1)),
        "coverage_90_mean": float(np.mean([item["coverage_90"] for item in fold_records])),
    }
    write_json(summary, output_dir / "metrics_internal.json")
    return summary


def _final_split(groups: np.ndarray, config: dict) -> OuterSplit:
    indices = np.arange(len(groups))
    cv = config["cross_validation"]
    reserve = GroupShuffleSplit(
        n_splits=1,
        test_size=cv["calibration_fraction"],
        random_state=cv["splitter_seed"] + 900,
    )
    fit_local, reserve_local = next(reserve.split(indices, groups=groups))
    fit_indices = indices[fit_local]
    reserve_indices = indices[reserve_local]
    relative_temperature = cv["temperature_fraction"] / cv["calibration_fraction"]
    secondary = GroupShuffleSplit(
        n_splits=1,
        test_size=relative_temperature,
        random_state=cv["splitter_seed"] + 901,
    )
    conformal_local, temperature_local = next(
        secondary.split(reserve_indices, groups=groups[reserve_indices])
    )
    return OuterSplit(
        fold=0,
        fit_indices=fit_indices,
        temperature_indices=reserve_indices[temperature_local],
        conformal_indices=reserve_indices[conformal_local],
        test_indices=np.array([], dtype=int),
    )


def run_external(config: dict) -> dict:
    validate_locked_config(config)
    output_dir = Path(config["run"]["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    data_config = config["data"]
    deam = load_prepared_table(data_config["deam_table"], data_config["feature_prefix"])
    pmemo = load_prepared_table(data_config["pmemo_table"], data_config["feature_prefix"])
    manifest = read_json(data_config["feature_manifest"])
    split = _final_split(deam.groups, config)
    partitions = {
        "temperature": (deam, split.temperature_indices),
        "conformal": (deam, split.conformal_indices),
        "external": (pmemo, np.arange(len(pmemo.x))),
    }
    predictions, preprocessor, epochs = _fit_members(
        deam,
        split.fit_indices,
        partitions,
        manifest,
        config,
        output_dir / "checkpoints",
        "final_deam",
    )
    temperature = fit_temperature(
        deam.y[split.temperature_indices],
        predictions["temperature"]["location"],
        predictions["temperature"]["scale"],
        predictions["temperature"]["degrees_of_freedom"],
        config["calibration"]["temperature_lower_bound"],
        config["calibration"]["temperature_upper_bound"],
        config["calibration"]["temperature_grid_size"],
    )
    radii = fit_conformal_radii(
        deam.y[split.conformal_indices],
        predictions["conformal"]["location"],
        predictions["conformal"]["scale"],
        temperature,
        config["calibration"]["nominal_levels"],
    )
    external = predictions["external"]
    raw_scale = external["scale"].copy()
    external["scale"] = raw_scale * temperature
    metrics = _evaluate(pmemo.y, pmemo.disagreement, external, config)
    coverage, area = coverage_and_area(
        pmemo.y,
        external["location"],
        raw_scale,
        temperature,
        radii["0.90"],
    )
    metrics.update(
        temperature=temperature,
        conformal_radii=radii,
        coverage_90=coverage,
        ellipse_area_90=area,
        selected_epochs=epochs,
        fine_tuning=False,
        recalibration=False,
    )
    frame = _prediction_frame(
        pmemo.song_ids, pmemo.y, pmemo.disagreement, external
    )
    frame.to_parquet(output_dir / "predictions_pmemo_frozen.parquet", index=False)
    write_json(metrics, output_dir / "metrics_external.json")
    write_json(
        {
            "temperature": temperature,
            "conformal_radii": radii,
            "temperature_song_ids": deam.song_ids[split.temperature_indices].tolist(),
            "conformal_song_ids": deam.song_ids[split.conformal_indices].tolist(),
        },
        output_dir / "calibration.json",
    )
    write_json(preprocessor.state_dict(), output_dir / "preprocessor_final.json")
    return metrics
