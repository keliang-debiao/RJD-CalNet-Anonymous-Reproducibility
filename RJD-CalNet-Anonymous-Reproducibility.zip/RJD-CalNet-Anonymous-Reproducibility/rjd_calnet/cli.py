from __future__ import annotations

import argparse
import json
from pathlib import Path

from .config import load_yaml
from .experiments import run_ablation_suite
from .pipeline import audit_data, run_cross_validation, run_external
from .reporting import run_paired_statistics, summarize_run


def _print(payload) -> None:
    print(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False, default=str))


def main() -> None:
    parser = argparse.ArgumentParser(description="RJD-CalNet reproducibility command line")
    subparsers = parser.add_subparsers(dest="command", required=True)
    for name in ("audit", "cross-validate", "external", "statistics"):
        command = subparsers.add_parser(name)
        command.add_argument("--config", default="configs/locked.yaml")
    ablations = subparsers.add_parser("ablations")
    ablations.add_argument("--config", default="configs/ablations/all.yaml")
    summary = subparsers.add_parser("summarize")
    summary.add_argument("--run-dir", default="outputs/locked_run")
    args = parser.parse_args()
    repository_root = Path(__file__).resolve().parents[1]
    if args.command == "summarize":
        _print(summarize_run(args.run_dir))
        return
    if args.command == "ablations":
        _print(run_ablation_suite(args.config, repository_root))
        return
    config = load_yaml(args.config)
    if args.command == "audit":
        _print(audit_data(config))
    elif args.command == "cross-validate":
        _print(run_cross_validation(config, repository_root))
    elif args.command == "external":
        _print(run_external(config))
    elif args.command == "statistics":
        _print(run_paired_statistics(config))


if __name__ == "__main__":
    main()

