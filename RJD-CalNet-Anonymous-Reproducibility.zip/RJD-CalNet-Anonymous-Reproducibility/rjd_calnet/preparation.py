from __future__ import annotations

import hashlib
import re
from pathlib import Path

import numpy as np
import pandas as pd

from .config import load_yaml
from .data.schema import build_feature_identities, encode_identities
from .utils import sha256_file, write_json


def read_table(path: str | Path) -> pd.DataFrame:
    source = Path(path)
    suffix = source.suffix.lower()
    if suffix == ".parquet":
        return pd.read_parquet(source)
    if suffix in {".tsv", ".txt"}:
        return pd.read_csv(source, sep="\t")
    if suffix == ".csv":
        return pd.read_csv(source)
    raise ValueError(f"Unsupported table format: {source}")


def _resolve_column(table: pd.DataFrame, aliases: list[str], role: str) -> str:
    direct = {str(column): column for column in table.columns}
    folded = {str(column).casefold(): column for column in table.columns}
    for alias in aliases:
        if alias in direct:
            return direct[alias]
        if alias.casefold() in folded:
            return folded[alias.casefold()]
    raise ValueError(f"Unable to resolve {role}; checked aliases {aliases}")


def _optional_column(table: pd.DataFrame, aliases: list[str]) -> str | None:
    try:
        return _resolve_column(table, aliases, "optional metadata")
    except ValueError:
        return None


def _normalize_identifier(value) -> str:
    text = str(value).strip().lower()
    text = re.sub(r"\.(wav|mp3|flac|ogg)$", "", text)
    return re.sub(r"[^a-z0-9]+", "_", text).strip("_")


def _detect_features(table: pd.DataFrame, settings: dict) -> list[str]:
    excluded = [re.compile(pattern) for pattern in settings["exclude_patterns"]]
    numeric = table.select_dtypes(include=[np.number]).columns.tolist()
    candidates = [
        column
        for column in numeric
        if not any(pattern.search(str(column)) for pattern in excluded)
    ]
    required = int(settings["minimum_numeric_features"])
    if len(candidates) != required:
        raise ValueError(
            f"Detected {len(candidates)} numeric feature columns; the locked schema requires {required}. "
            "Update only configs/data_schema.yaml after auditing the public headers."
        )
    return [str(column) for column in candidates]


def _source_groups(table: pd.DataFrame, id_column: str, artist_column, title_column) -> pd.Series:
    groups = []
    for _, row in table.iterrows():
        song_id = _normalize_identifier(row[id_column])
        artist = _normalize_identifier(row[artist_column]) if artist_column else ""
        title = _normalize_identifier(row[title_column]) if title_column else ""
        key = f"{artist}|{title}" if artist or title else song_id
        groups.append(hashlib.sha256(key.encode("utf-8")).hexdigest()[:20])
    return pd.Series(groups, index=table.index, dtype="string")


def _canonical_labels(table: pd.DataFrame, schema: dict, normalize_deam: bool) -> pd.DataFrame:
    columns = {
        "valence_mean": _resolve_column(table, schema["valence_mean_aliases"], "valence mean"),
        "arousal_mean": _resolve_column(table, schema["arousal_mean_aliases"], "arousal mean"),
        "valence_sd": _resolve_column(table, schema["valence_sd_aliases"], "valence listener SD"),
        "arousal_sd": _resolve_column(table, schema["arousal_sd_aliases"], "arousal listener SD"),
    }
    result = table[list(columns.values())].rename(columns={value: key for key, value in columns.items()})
    result = result.apply(pd.to_numeric, errors="coerce")
    if normalize_deam:
        means = ["valence_mean", "arousal_mean"]
        deviations = ["valence_sd", "arousal_sd"]
        if result[means].max().max() > 1.0:
            result[means] = (result[means] - 1.0) / 8.0
        if result[deviations].max().max() > 0.5:
            result[deviations] = result[deviations] / 8.0
    if result.isna().any().any():
        raise ValueError("Primary label columns contain missing or non-numeric values")
    return result.astype(np.float32)


def prepare_datasets(
    deam_features_path: str,
    deam_labels_path: str,
    pmemo_path: str,
    output_dir: str,
    schema_path: str,
) -> dict:
    schema = load_yaml(schema_path)
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)

    deam_features = read_table(deam_features_path)
    deam_labels = read_table(deam_labels_path)
    deam_id_features = _resolve_column(deam_features, schema["deam"]["id_aliases"], "DEAM feature ID")
    deam_id_labels = _resolve_column(deam_labels, schema["deam"]["id_aliases"], "DEAM label ID")
    deam_features = deam_features.copy()
    deam_labels = deam_labels.copy()
    deam_features["_join_id"] = deam_features[deam_id_features].map(_normalize_identifier)
    deam_labels["_join_id"] = deam_labels[deam_id_labels].map(_normalize_identifier)
    if deam_features["_join_id"].duplicated().any() or deam_labels["_join_id"].duplicated().any():
        raise ValueError("DEAM input identifiers are not unique before merging")
    deam = deam_features.merge(deam_labels, on="_join_id", how="inner", suffixes=("", "__label"))
    if len(deam) != 1802:
        raise ValueError(f"DEAM merge produced {len(deam)} rows; the locked audit requires 1802")
    feature_columns = _detect_features(deam_features, schema["feature_detection"])
    labels = _canonical_labels(deam, schema["deam"], normalize_deam=True)
    artist_column = _optional_column(deam, schema["deam"]["artist_aliases"])
    title_column = _optional_column(deam, schema["deam"]["title_aliases"])
    deam_prepared = pd.DataFrame({"song_id": deam["_join_id"].astype(str)})
    deam_prepared["source_group"] = _source_groups(
        deam, "_join_id", artist_column, title_column
    )
    for column in labels:
        deam_prepared[column] = labels[column].to_numpy()
    for column in feature_columns:
        deam_prepared[f"feat__{column}"] = pd.to_numeric(deam[column], errors="coerce").astype(np.float32)

    identities = build_feature_identities(
        [f"feat__{column}" for column in feature_columns],
        schema["feature_detection"]["group_patterns"],
        schema["feature_detection"]["fallback_group"],
    )
    manifest = encode_identities(identities)
    manifest["feature_count"] = len(feature_columns)
    manifest["deam_source_sha256"] = sha256_file(deam_features_path)

    pmemo = read_table(pmemo_path).copy()
    pmemo_id = _resolve_column(pmemo, schema["pmemo"]["id_aliases"], "PMEmo ID")
    pmemo["_join_id"] = pmemo[pmemo_id].map(_normalize_identifier)
    if pmemo["_join_id"].duplicated().any():
        raise ValueError("PMEmo input identifiers are not unique")
    missing_features = [column for column in feature_columns if column not in pmemo.columns]
    if missing_features:
        raise ValueError(
            f"PMEmo is missing {len(missing_features)} frozen feature columns; no target-based remapping is permitted"
        )
    pmemo_labels = _canonical_labels(pmemo, schema["pmemo"], normalize_deam=False)
    complete = pmemo_labels.notna().all(axis=1)
    complete &= np.isfinite(pmemo[feature_columns].to_numpy(dtype=np.float64)).all(axis=1)
    pmemo = pmemo.loc[complete].reset_index(drop=True)
    pmemo_labels = pmemo_labels.loc[complete].reset_index(drop=True)
    if len(pmemo) != 767:
        raise ValueError(f"PMEmo preparation produced {len(pmemo)} rows; the locked audit requires 767")
    pmemo_prepared = pd.DataFrame({"song_id": pmemo["_join_id"].astype(str)})
    pmemo_prepared["source_group"] = [f"pmemo_{value}" for value in pmemo_prepared["song_id"]]
    for column in pmemo_labels:
        pmemo_prepared[column] = pmemo_labels[column].to_numpy()
    for column in feature_columns:
        pmemo_prepared[f"feat__{column}"] = pd.to_numeric(pmemo[column], errors="coerce").astype(np.float32)

    deam_path = output / "deam.parquet"
    pmemo_path_out = output / "pmemo.parquet"
    deam_prepared.to_parquet(deam_path, index=False)
    pmemo_prepared.to_parquet(pmemo_path_out, index=False)
    write_json(manifest, output / "feature_manifest.json")
    deam_prepared[["song_id", "source_group"]].to_csv(output / "deam_groups.csv", index=False)
    audit = {
        "deam_rows": len(deam_prepared),
        "pmemo_rows": len(pmemo_prepared),
        "feature_count": len(feature_columns),
        "deam_groups": int(deam_prepared["source_group"].nunique()),
        "deam_table_sha256": sha256_file(deam_path),
        "pmemo_table_sha256": sha256_file(pmemo_path_out),
        "feature_manifest_sha256": sha256_file(output / "feature_manifest.json"),
    }
    write_json(audit, output / "preparation_audit.json")
    return audit

