from __future__ import annotations

import copy
from pathlib import Path

from .config import load_yaml, resolved_variant
from .pipeline import run_cross_validation, run_external
from .utils import write_json


def run_ablation_suite(path: str, repository_root: Path) -> dict:
    suite = load_yaml(path)
    base = load_yaml(suite["base_config"])
    root = Path(suite["output_dir"])
    completed = {}
    for name, overrides in suite["variants"].items():
        config = resolved_variant(base, overrides)
        config["run"]["name"] = f"ablation_{name}"
        config["run"]["output_dir"] = str(root / name)
        internal = run_cross_validation(config, repository_root)
        external = run_external(config)
        completed[name] = {"internal": internal, "external": external}
    write_json(completed, root / "ablation_summary.json")
    return completed

