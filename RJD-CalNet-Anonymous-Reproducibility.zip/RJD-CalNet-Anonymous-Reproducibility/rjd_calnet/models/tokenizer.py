from __future__ import annotations

import torch
from torch import nn


class DescriptorFunctionalTokenizer(nn.Module):
    def __init__(
        self,
        descriptor_ids,
        functional_ids,
        group_ids,
        n_descriptors: int,
        n_functionals: int,
        n_groups: int = 7,
        d_model: int = 64,
        dropout: float = 0.2,
        use_identities: bool = True,
    ):
        super().__init__()
        self.n_groups = n_groups
        self.use_identities = use_identities
        self.register_buffer("descriptor_ids", torch.as_tensor(descriptor_ids, dtype=torch.long))
        self.register_buffer("functional_ids", torch.as_tensor(functional_ids, dtype=torch.long))
        self.register_buffer("group_ids", torch.as_tensor(group_ids, dtype=torch.long))
        self.value_projection = nn.Sequential(nn.Linear(2, d_model), nn.GELU())
        self.descriptor_embedding = nn.Embedding(n_descriptors, d_model)
        self.functional_embedding = nn.Embedding(n_functionals, d_model)
        self.pool_projection = nn.Linear(d_model, d_model)
        self.group_queries = nn.Parameter(torch.empty(n_groups, d_model))
        self.dropout = nn.Dropout(dropout)
        nn.init.normal_(self.group_queries, std=0.02)

    def forward(self, x: torch.Tensor, missing: torch.Tensor):
        scalar_input = torch.stack((x, missing), dim=-1)
        tokens = self.value_projection(scalar_input)
        if self.use_identities:
            identity = self.descriptor_embedding(self.descriptor_ids)
            identity = identity + self.functional_embedding(self.functional_ids)
            tokens = tokens + identity.unsqueeze(0)
        tokens = self.dropout(tokens)
        group_tokens = []
        group_deviation = []
        group_missingness = []
        for group in range(self.n_groups):
            mask = self.group_ids == group
            if not bool(mask.any()):
                raise ValueError(f"Descriptor group {group} has no assigned features")
            selected = tokens[:, mask, :]
            query = self.group_queries[group]
            logits = torch.einsum("bfd,d->bf", torch.tanh(self.pool_projection(selected)), query)
            weights = torch.softmax(logits, dim=1)
            group_tokens.append(torch.einsum("bf,bfd->bd", weights, selected))
            group_deviation.append(torch.median(torch.abs(x[:, mask]), dim=1).values)
            group_missingness.append(missing[:, mask].mean(dim=1))
        return (
            torch.stack(group_tokens, dim=1),
            torch.stack(group_deviation, dim=1),
            torch.stack(group_missingness, dim=1),
        )

