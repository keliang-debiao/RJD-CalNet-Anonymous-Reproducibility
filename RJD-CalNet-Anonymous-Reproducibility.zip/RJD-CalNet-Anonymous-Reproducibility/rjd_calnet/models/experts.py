from __future__ import annotations

import torch
from torch import nn


class LocalExpert(nn.Module):
    def __init__(self, n_groups: int, d_model: int, expansion: int, dropout: float):
        super().__init__()
        hidden = d_model * expansion
        self.weight_in = nn.Parameter(torch.empty(n_groups, d_model, hidden))
        self.bias_in = nn.Parameter(torch.zeros(n_groups, hidden))
        self.weight_out = nn.Parameter(torch.empty(n_groups, hidden, d_model))
        self.bias_out = nn.Parameter(torch.zeros(n_groups, d_model))
        self.dropout = nn.Dropout(dropout)
        nn.init.xavier_uniform_(self.weight_in)
        nn.init.xavier_uniform_(self.weight_out)

    def forward(self, tokens: torch.Tensor) -> torch.Tensor:
        hidden = torch.einsum("bgd,gdh->bgh", tokens, self.weight_in) + self.bias_in
        hidden = self.dropout(torch.nn.functional.gelu(hidden))
        return torch.einsum("bgh,ghd->bgd", hidden, self.weight_out) + self.bias_out


class CrossGroupExpert(nn.Module):
    def __init__(self, d_model: int, n_heads: int, dropout: float):
        super().__init__()
        self.attention = nn.MultiheadAttention(
            d_model, n_heads, dropout=dropout, batch_first=True
        )
        self.output = nn.Sequential(nn.Linear(d_model, d_model), nn.Dropout(dropout))

    def forward(self, tokens: torch.Tensor) -> torch.Tensor:
        groups = tokens.shape[1]
        self_mask = torch.eye(groups, device=tokens.device, dtype=torch.bool)
        attended, _ = self.attention(
            tokens, tokens, tokens, attn_mask=self_mask, need_weights=False
        )
        return self.output(attended)


class LowRankBilinearExpert(nn.Module):
    def __init__(self, n_groups: int, d_model: int, rank: int, dropout: float):
        super().__init__()
        self.left = nn.Parameter(torch.empty(n_groups, d_model, rank))
        self.right = nn.Parameter(torch.empty(n_groups, d_model, rank))
        self.output = nn.Parameter(torch.empty(n_groups, rank, d_model))
        self.bias = nn.Parameter(torch.zeros(n_groups, d_model))
        self.dropout = nn.Dropout(dropout)
        nn.init.xavier_uniform_(self.left)
        nn.init.xavier_uniform_(self.right)
        nn.init.xavier_uniform_(self.output)

    def forward(self, tokens: torch.Tensor) -> torch.Tensor:
        groups = tokens.shape[1]
        context = (tokens.sum(dim=1, keepdim=True) - tokens) / max(groups - 1, 1)
        left = torch.einsum("bgd,gdr->bgr", tokens, self.left)
        right = torch.einsum("bgd,gdr->bgr", context, self.right)
        interaction = left * right
        result = torch.einsum("bgr,grd->bgd", interaction, self.output) + self.bias
        return self.dropout(result)


class ReliabilityGuidedExpertLayer(nn.Module):
    def __init__(
        self,
        n_groups: int,
        d_model: int,
        n_heads: int,
        n_experts: int,
        local_expansion: int,
        low_rank_dim: int,
        router_hidden: int,
        dropout: float,
        use_reliability_gating: bool = True,
    ):
        super().__init__()
        all_experts = [
            LocalExpert(n_groups, d_model, local_expansion, dropout),
            CrossGroupExpert(d_model, n_heads, dropout),
            LowRankBilinearExpert(n_groups, d_model, low_rank_dim, dropout),
        ]
        self.experts = nn.ModuleList(all_experts[:n_experts])
        self.router = nn.Sequential(
            nn.Linear(d_model + 1, router_hidden),
            nn.GELU(),
            nn.Linear(router_hidden, n_experts),
        )
        self.norm = nn.LayerNorm(d_model)
        self.use_reliability_gating = use_reliability_gating

    def forward(self, tokens: torch.Tensor, reliability: torch.Tensor):
        router_input = torch.cat((tokens, reliability.unsqueeze(-1)), dim=-1)
        probabilities = torch.softmax(self.router(router_input), dim=-1)
        outputs = torch.stack([expert(tokens) for expert in self.experts], dim=-2)
        mixed = torch.sum(probabilities.unsqueeze(-1) * outputs, dim=-2)
        gate = reliability.unsqueeze(-1) if self.use_reliability_gating else 1.0
        return self.norm(tokens + gate * mixed), probabilities


class ReliabilityEstimator(nn.Module):
    def __init__(self, d_model: int, hidden: int, dropout: float):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(d_model + 2, hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, 1),
        )

    def forward(
        self, tokens: torch.Tensor, deviation: torch.Tensor, missingness: torch.Tensor
    ) -> torch.Tensor:
        values = torch.cat(
            (tokens, deviation.unsqueeze(-1), missingness.unsqueeze(-1)), dim=-1
        )
        return torch.sigmoid(self.net(values).squeeze(-1))
