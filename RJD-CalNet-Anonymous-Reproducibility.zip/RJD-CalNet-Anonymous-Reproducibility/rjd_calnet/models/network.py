from __future__ import annotations

import torch
from torch import nn

from .experts import ReliabilityEstimator, ReliabilityGuidedExpertLayer
from .head import JointStudentTDisagreementHead
from .tokenizer import DescriptorFunctionalTokenizer


class RJDCalNet(nn.Module):
    def __init__(self, manifest: dict, config: dict):
        super().__init__()
        model = config["model"]
        features = manifest["features"]
        descriptor_ids = [item["descriptor_id"] for item in features]
        functional_ids = [item["functional_id"] for item in features]
        group_ids = [item["group_id"] for item in features]
        n_groups = len(manifest["group_order"])
        self.tokenizer = DescriptorFunctionalTokenizer(
            descriptor_ids=descriptor_ids,
            functional_ids=functional_ids,
            group_ids=group_ids,
            n_descriptors=len(manifest["descriptor_vocab"]),
            n_functionals=len(manifest["functional_vocab"]),
            n_groups=n_groups,
            d_model=model["d_model"],
            dropout=model["dropout"],
            use_identities=model.get("use_descriptor_functional_identities", True),
        )
        self.reliability_estimator = ReliabilityEstimator(
            model["d_model"], model["reliability_hidden"], model["dropout"]
        )
        self.layers = nn.ModuleList(
            [
                ReliabilityGuidedExpertLayer(
                    n_groups=n_groups,
                    d_model=model["d_model"],
                    n_heads=model["n_heads"],
                    n_experts=model["n_experts"],
                    local_expansion=model["local_expansion"],
                    low_rank_dim=model["low_rank_dim"],
                    router_hidden=model["router_hidden"],
                    dropout=model["dropout"],
                    use_reliability_gating=model.get("use_reliability_gating", True),
                )
                for _ in range(model["n_layers"])
            ]
        )
        self.pool_query = nn.Parameter(torch.empty(model["d_model"]))
        self.pool_strength = nn.Parameter(
            torch.tensor(float(model["reliability_pool_strength"]))
        )
        nn.init.normal_(self.pool_query, std=0.02)
        self.head = JointStudentTDisagreementHead(
            d_model=model["d_model"],
            minimum_df=model["minimum_df"],
            disagreement_ceiling=model["disagreement_ceiling"],
            full_covariance=model.get("full_covariance", True),
            distribution=model.get("distribution", "student_t"),
        )
        self.use_reliability_gating = model.get("use_reliability_gating", True)

    def forward(self, x: torch.Tensor, missing: torch.Tensor) -> dict[str, torch.Tensor]:
        tokens, deviation, missingness = self.tokenizer(x, missing)
        reliability = self.reliability_estimator(tokens, deviation, missingness)
        if not self.use_reliability_gating:
            reliability_for_flow = torch.ones_like(reliability)
        else:
            reliability_for_flow = reliability
        routing = []
        for layer in self.layers:
            tokens, probabilities = layer(tokens, reliability_for_flow)
            routing.append(probabilities)
        relevance = torch.einsum("bgd,d->bg", tokens, self.pool_query)
        relevance = relevance + self.pool_strength * torch.log(reliability_for_flow + 1.0e-6)
        pooling_weights = torch.softmax(relevance, dim=1)
        representation = torch.einsum("bg,bgd->bd", pooling_weights, tokens)
        outputs = self.head(representation)
        outputs.update(
            reliability=reliability,
            pooling_weights=pooling_weights,
            routing=torch.stack(routing, dim=1),
            representation=representation,
        )
        return outputs
