from __future__ import annotations

import torch
import torch.nn.functional as functional
from torch import nn


class JointStudentTDisagreementHead(nn.Module):
    def __init__(
        self,
        d_model: int,
        minimum_df: float = 2.05,
        disagreement_ceiling: float = 0.5,
        full_covariance: bool = True,
        distribution: str = "student_t",
    ):
        super().__init__()
        self.location = nn.Linear(d_model, 2)
        self.cholesky = nn.Linear(d_model, 3)
        self.df = nn.Linear(d_model, 1)
        self.disagreement = nn.Linear(d_model, 2)
        self.minimum_df = minimum_df
        self.disagreement_ceiling = disagreement_ceiling
        self.full_covariance = full_covariance
        self.distribution = distribution

    def forward(self, representation: torch.Tensor) -> dict[str, torch.Tensor]:
        location = torch.sigmoid(self.location(representation))
        raw = self.cholesky(representation)
        diagonal_1 = functional.softplus(raw[:, 0]) + 1.0e-4
        off_diagonal = raw[:, 1] if self.full_covariance else torch.zeros_like(raw[:, 1])
        diagonal_2 = functional.softplus(raw[:, 2]) + 1.0e-4
        cholesky = torch.zeros(
            representation.shape[0], 2, 2, device=representation.device, dtype=representation.dtype
        )
        cholesky[:, 0, 0] = diagonal_1
        cholesky[:, 1, 0] = off_diagonal
        cholesky[:, 1, 1] = diagonal_2
        scale = cholesky @ cholesky.transpose(-1, -2)
        if self.distribution == "gaussian":
            degrees_of_freedom = torch.full_like(raw[:, 0], 1.0e6)
        else:
            degrees_of_freedom = self.minimum_df + functional.softplus(self.df(representation).squeeze(-1))
        listener_disagreement = self.disagreement_ceiling * torch.sigmoid(
            self.disagreement(representation)
        )
        covariance_factor = degrees_of_freedom / (degrees_of_freedom - 2.0)
        covariance = scale * covariance_factor[:, None, None]
        return {
            "location": location,
            "scale": scale,
            "covariance": covariance,
            "degrees_of_freedom": degrees_of_freedom,
            "listener_disagreement": listener_disagreement,
        }

