from __future__ import annotations

import math

import torch
import torch.nn.functional as functional


def joint_student_t_nll(
    target: torch.Tensor,
    location: torch.Tensor,
    scale: torch.Tensor,
    degrees_of_freedom: torch.Tensor,
) -> torch.Tensor:
    dimension = target.shape[-1]
    residual = target - location
    solution = torch.linalg.solve(scale, residual.unsqueeze(-1)).squeeze(-1)
    mahalanobis = torch.sum(residual * solution, dim=-1)
    _, logdet = torch.linalg.slogdet(scale)
    df = degrees_of_freedom
    log_density = (
        torch.lgamma((df + dimension) / 2.0)
        - torch.lgamma(df / 2.0)
        - 0.5 * (logdet + dimension * torch.log(df * math.pi))
        - 0.5 * (df + dimension) * torch.log1p(mahalanobis / df)
    )
    return -log_density.mean()


def disagreement_loss(
    prediction: torch.Tensor, target: torch.Tensor, delta: float = 0.20
) -> torch.Tensor:
    residual = torch.log(prediction.clamp_min(1.0e-6)) - torch.log(target.clamp_min(1.0e-6))
    return functional.huber_loss(residual, torch.zeros_like(residual), delta=delta)


def reliability_loss(prediction: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    return functional.binary_cross_entropy(prediction.clamp(1.0e-6, 1.0 - 1.0e-6), target)


def _matrix_log_spd(matrix: torch.Tensor) -> torch.Tensor:
    eigenvalues, eigenvectors = torch.linalg.eigh(matrix)
    log_values = torch.log(eigenvalues.clamp_min(1.0e-6))
    return eigenvectors @ torch.diag_embed(log_values) @ eigenvectors.transpose(-1, -2)


def consistency_loss(clean: dict, corrupted: dict, scale_weight: float = 0.10) -> torch.Tensor:
    location_term = torch.mean(torch.sum((clean["location"] - corrupted["location"]) ** 2, dim=-1))
    log_clean = _matrix_log_spd(clean["scale"])
    log_corrupted = _matrix_log_spd(corrupted["scale"])
    scale_term = torch.mean(torch.sum((log_clean - log_corrupted) ** 2, dim=(-2, -1)))
    return location_term + scale_weight * scale_term


def routing_balance_loss(routing: torch.Tensor) -> torch.Tensor:
    usage = routing.mean(dim=(0, 2))
    target = torch.full_like(usage, 1.0 / usage.shape[-1])
    return torch.mean((usage - target) ** 2)


def controlled_corruption(
    x: torch.Tensor,
    missing: torch.Tensor,
    group_ids: torch.Tensor,
    config: dict,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    batch_size = x.shape[0]
    n_groups = int(group_ids.max().item()) + 1
    corrupted_x = x.clone()
    corrupted_missing = missing.clone()
    reliability_target = torch.ones(batch_size, n_groups, device=x.device, dtype=x.dtype)
    fraction_min = config["minimum_fraction"]
    fraction_max = config["maximum_fraction"]
    probabilities = torch.tensor(
        [
            config["masking_probability"],
            config["noise_probability"],
            config["permutation_probability"],
        ],
        device=x.device,
        dtype=x.dtype,
    )
    probabilities = probabilities / probabilities.sum()
    for row in range(batch_size):
        group = int(torch.randint(n_groups, (1,), device=x.device).item())
        feature_positions = torch.where(group_ids == group)[0]
        fraction = float(torch.empty(1, device=x.device).uniform_(fraction_min, fraction_max).item())
        count = max(1, int(round(fraction * len(feature_positions))))
        selected = feature_positions[
            torch.randperm(len(feature_positions), device=x.device)[:count]
        ]
        operation = int(torch.multinomial(probabilities, 1).item())
        if operation == 0:
            corrupted_x[row, selected] = 0.0
            corrupted_missing[row, selected] = 1.0
        elif operation == 1:
            sigma = float(
                torch.empty(1, device=x.device)
                .uniform_(config["noise_sigma_minimum"], config["noise_sigma_maximum"])
                .item()
            )
            corrupted_x[row, selected] += sigma * torch.randn_like(corrupted_x[row, selected])
        else:
            source_row = int(torch.randint(batch_size, (1,), device=x.device).item())
            corrupted_x[row, selected] = x[source_row, selected]
        reliability_target[row, group] = 0.0
    return corrupted_x, corrupted_missing, reliability_target


def total_training_loss(
    model,
    batch: dict[str, torch.Tensor],
    loss_config: dict,
    corruption_config: dict,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    clean = model(batch["x"], batch["missing"])
    corrupted_x, corrupted_missing, reliability_target = controlled_corruption(
        batch["x"], batch["missing"], model.tokenizer.group_ids, corruption_config
    )
    corrupted = model(corrupted_x, corrupted_missing)
    components = {
        "main": joint_student_t_nll(
            batch["y"], clean["location"], clean["scale"], clean["degrees_of_freedom"]
        ),
        "disagreement": disagreement_loss(
            clean["listener_disagreement"],
            batch["disagreement"],
            delta=loss_config["disagreement_huber_delta"],
        ),
        "reliability": reliability_loss(corrupted["reliability"], reliability_target),
        "consistency": consistency_loss(
            clean, corrupted, scale_weight=loss_config["consistency_scale_weight"]
        ),
        "balance": routing_balance_loss(clean["routing"]),
    }
    total = (
        components["main"]
        + loss_config["disagreement_weight"] * components["disagreement"]
        + loss_config["reliability_weight"] * components["reliability"]
        + loss_config["consistency_weight"] * components["consistency"]
        + loss_config["balance_weight"] * components["balance"]
    )
    return total, components

