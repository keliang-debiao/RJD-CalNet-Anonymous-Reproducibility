from __future__ import annotations

import numpy as np
from scipy.stats import wilcoxon


def bootstrap_mean_ci(
    values: np.ndarray,
    resamples: int = 10000,
    seed: int = 16180,
    groups: np.ndarray | None = None,
    confidence: float = 0.95,
) -> tuple[float, float]:
    values = np.asarray(values, dtype=np.float64)
    generator = np.random.default_rng(seed)
    estimates = np.empty(resamples, dtype=np.float64)
    if groups is None:
        for index in range(resamples):
            sampled = generator.integers(0, len(values), len(values))
            estimates[index] = values[sampled].mean()
    else:
        groups = np.asarray(groups)
        unique = np.unique(groups)
        group_positions = {group: np.where(groups == group)[0] for group in unique}
        for index in range(resamples):
            sampled_groups = generator.choice(unique, size=len(unique), replace=True)
            sampled_values = np.concatenate([values[group_positions[group]] for group in sampled_groups])
            estimates[index] = sampled_values.mean()
    alpha = 1.0 - confidence
    return tuple(np.quantile(estimates, [alpha / 2.0, 1.0 - alpha / 2.0]).tolist())


def holm_adjust(p_values: list[float]) -> list[float]:
    values = np.asarray(p_values, dtype=np.float64)
    order = np.argsort(values)
    adjusted = np.empty_like(values)
    running = 0.0
    total = len(values)
    for rank, position in enumerate(order):
        candidate = min(1.0, (total - rank) * values[position])
        running = max(running, candidate)
        adjusted[position] = running
    return adjusted.tolist()


def rank_biserial_favorable(differences: np.ndarray) -> float:
    values = np.asarray(differences, dtype=np.float64)
    values = values[values != 0]
    if len(values) == 0:
        return 0.0
    order = np.argsort(np.abs(values))
    ranks = np.empty(len(values), dtype=np.float64)
    ranks[order] = np.arange(1, len(values) + 1)
    positive = ranks[values > 0].sum()
    negative = ranks[values < 0].sum()
    return float(abs(positive - negative) / (positive + negative))


def paired_comparison(
    proposed_errors: np.ndarray,
    comparator_errors: np.ndarray,
    resamples: int = 10000,
    seed: int = 16180,
    groups: np.ndarray | None = None,
) -> dict[str, float | list[float]]:
    differences = np.asarray(proposed_errors) - np.asarray(comparator_errors)
    statistic = wilcoxon(differences, zero_method="pratt", alternative="two-sided")
    lower, upper = bootstrap_mean_ci(differences, resamples, seed, groups)
    return {
        "mean_difference": float(differences.mean()),
        "bootstrap_ci": [lower, upper],
        "raw_p": float(statistic.pvalue),
        "rank_biserial_favorable": rank_biserial_favorable(differences),
    }

