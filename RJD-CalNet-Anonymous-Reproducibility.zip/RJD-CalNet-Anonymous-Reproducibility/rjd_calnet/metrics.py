from __future__ import annotations

import numpy as np
from scipy.stats import pearsonr, spearmanr
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from .calibration import student_t_nll_numpy


def mean_euclidean_distance(target: np.ndarray, prediction: np.ndarray) -> float:
    return float(np.mean(np.linalg.norm(target - prediction, axis=1)))


def concordance_correlation_coefficient(target: np.ndarray, prediction: np.ndarray) -> float:
    target = np.asarray(target, dtype=np.float64)
    prediction = np.asarray(prediction, dtype=np.float64)
    covariance = np.mean((target - target.mean()) * (prediction - prediction.mean()))
    denominator = target.var() + prediction.var() + (target.mean() - prediction.mean()) ** 2
    return float(2.0 * covariance / denominator) if denominator > 0 else float("nan")


def point_metrics(target: np.ndarray, prediction: np.ndarray) -> dict[str, float]:
    result = {"med": mean_euclidean_distance(target, prediction)}
    for index, suffix in enumerate(("v", "a")):
        result[f"mae_{suffix}"] = float(mean_absolute_error(target[:, index], prediction[:, index]))
        result[f"rmse_{suffix}"] = float(
            mean_squared_error(target[:, index], prediction[:, index]) ** 0.5
        )
        result[f"r2_{suffix}"] = float(r2_score(target[:, index], prediction[:, index]))
        result[f"pearson_{suffix}"] = float(pearsonr(target[:, index], prediction[:, index]).statistic)
        result[f"ccc_{suffix}"] = concordance_correlation_coefficient(
            target[:, index], prediction[:, index]
        )
    return result


def disagreement_metrics(target: np.ndarray, prediction: np.ndarray) -> dict[str, float]:
    result: dict[str, float] = {}
    for index, suffix in enumerate(("v", "a")):
        result[f"mae_{suffix}"] = float(mean_absolute_error(target[:, index], prediction[:, index]))
        result[f"rmse_{suffix}"] = float(
            mean_squared_error(target[:, index], prediction[:, index]) ** 0.5
        )
        result[f"spearman_{suffix}"] = float(
            spearmanr(target[:, index], prediction[:, index]).statistic
        )
    return result


def multivariate_energy_score(
    target: np.ndarray,
    location: np.ndarray,
    scale: np.ndarray,
    degrees_of_freedom: np.ndarray,
    draws: int = 2000,
    seed: int = 2026,
) -> float:
    generator = np.random.default_rng(seed)
    n = len(target)
    scores = np.empty(n, dtype=np.float64)
    for index in range(n):
        normal = generator.multivariate_normal(np.zeros(2), scale[index], size=draws)
        chi_square = generator.chisquare(degrees_of_freedom[index], size=draws)
        samples = location[index] + normal / np.sqrt(chi_square[:, None] / degrees_of_freedom[index])
        first = np.linalg.norm(samples - target[index], axis=1).mean()
        paired = np.roll(samples, 1, axis=0)
        second = 0.5 * np.linalg.norm(samples - paired, axis=1).mean()
        scores[index] = first - second
    return float(scores.mean())


def distribution_metrics(target: np.ndarray, prediction: dict, draws: int = 2000) -> dict[str, float]:
    return {
        "joint_nll": float(
            student_t_nll_numpy(
                target,
                prediction["location"],
                prediction["scale"],
                prediction["degrees_of_freedom"],
            ).mean()
        ),
        "energy_score": multivariate_energy_score(
            target,
            prediction["location"],
            prediction["scale"],
            prediction["degrees_of_freedom"],
            draws=draws,
        ),
    }


def area_under_risk_coverage(
    target: np.ndarray,
    prediction: np.ndarray,
    uncertainty: np.ndarray,
    minimum_coverage: float = 0.10,
    step: float = 0.01,
) -> float:
    order = np.argsort(uncertainty)
    errors = np.linalg.norm(target[order] - prediction[order], axis=1)
    coverages = np.arange(minimum_coverage, 1.0 + 0.5 * step, step)
    risks = []
    for coverage in coverages:
        count = max(1, int(np.ceil(coverage * len(errors))))
        risks.append(errors[:count].mean())
    return float(np.trapezoid(risks, coverages) / (coverages[-1] - coverages[0]))

