from __future__ import annotations

import copy
from pathlib import Path
from typing import Any

import yaml


def load_yaml(path: str | Path) -> dict[str, Any]:
    source = Path(path)
    with source.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle)
    if not isinstance(data, dict):
        raise ValueError(f"Configuration must be a mapping: {source}")
    return data


def save_yaml(data: dict[str, Any], path: str | Path) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", encoding="utf-8") as handle:
        yaml.safe_dump(data, handle, sort_keys=False, allow_unicode=True)


def set_nested(config: dict[str, Any], dotted_key: str, value: Any) -> None:
    node = config
    parts = dotted_key.split(".")
    for part in parts[:-1]:
        node = node.setdefault(part, {})
    node[parts[-1]] = value


def resolved_variant(base: dict[str, Any], overrides: dict[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(base)
    for key, value in overrides.items():
        set_nested(result, key, value)
    return result


def validate_locked_config(config: dict[str, Any]) -> None:
    cv = config["cross_validation"]
    if cv["outer_folds"] != 5 or cv["inner_folds"] != 3:
        raise ValueError("The locked protocol requires five outer folds and three inner folds")
    fractions = (
        cv["temperature_fraction"],
        cv["conformal_fraction"],
        cv["calibration_fraction"],
    )
    if abs(fractions[0] + fractions[1] - fractions[2]) > 1e-12:
        raise ValueError("Temperature and conformal fractions must sum to calibration_fraction")
    if config["training"]["seeds"] != [11, 23, 47]:
        raise ValueError("The locked ensemble seeds are 11, 23, and 47")
    if config["model"]["n_experts"] not in (1, 3):
        raise ValueError("The supported expert count is one or three")

