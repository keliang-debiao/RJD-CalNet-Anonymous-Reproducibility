from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import optuna
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.model_selection import GroupKFold
from sklearn.multioutput import MultiOutputRegressor
from sklearn.neural_network import MLPRegressor

from .config import load_yaml
from .data.dataset import load_prepared_table
from .data.preprocessing import RobustFoldPreprocessor
from .data.splits import grouped_outer_splits
from .metrics import mean_euclidean_distance
from .pipeline import _final_split
from .utils import write_json


def _parameters(name: str, trial: optuna.Trial) -> dict:
    if name == "ridge":
        return {"alpha": trial.suggest_float("alpha", 1.0e-6, 1.0e3, log=True)}
    if name == "random_forest":
        return {
            "n_estimators": trial.suggest_int("n_estimators", 500, 1500, step=250),
            "max_depth": trial.suggest_categorical("max_depth", [8, 16, 32, None]),
            "max_features": trial.suggest_float("max_features", 0.2, 1.0),
            "min_samples_leaf": trial.suggest_int("min_samples_leaf", 1, 5),
        }
    if name == "xgboost":
        return {
            "n_estimators": trial.suggest_int("n_estimators", 300, 2000, step=100),
            "max_depth": trial.suggest_int("max_depth", 3, 8),
            "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.2, log=True),
            "subsample": trial.suggest_float("subsample", 0.6, 1.0),
            "colsample_bytree": trial.suggest_float("colsample_bytree", 0.4, 1.0),
            "reg_lambda": trial.suggest_float("reg_lambda", 1.0e-4, 10.0, log=True),
        }
    if name == "mlp":
        layers = trial.suggest_int("layers", 2, 5)
        width = trial.suggest_categorical("width", [128, 256, 384, 512])
        return {
            "hidden_layer_sizes": tuple([width] * layers),
            "alpha": trial.suggest_float("alpha", 1.0e-6, 1.0e-2, log=True),
            "learning_rate_init": trial.suggest_float("learning_rate_init", 1.0e-4, 3.0e-3, log=True),
        }
    if name == "tabnet":
        return {
            "n_d": trial.suggest_categorical("n_d", [16, 32, 48, 64]),
            "n_a": trial.suggest_categorical("n_a", [16, 32, 48, 64]),
            "n_steps": trial.suggest_int("n_steps", 3, 8),
            "gamma": trial.suggest_float("gamma", 1.1, 2.0),
        }
    raise ValueError(f"Unsupported standard baseline: {name}")


def _build(name: str, parameters: dict, seed: int):
    if name == "ridge":
        return Ridge(**parameters)
    if name == "random_forest":
        return RandomForestRegressor(**parameters, random_state=seed, n_jobs=-1)
    if name == "xgboost":
        from xgboost import XGBRegressor

        base = XGBRegressor(
            **parameters,
            objective="reg:squarederror",
            random_state=seed,
            n_jobs=-1,
            tree_method="hist",
        )
        return MultiOutputRegressor(base, n_jobs=2)
    if name == "mlp":
        return MLPRegressor(
            **parameters,
            activation="relu",
            batch_size=64,
            max_iter=250,
            early_stopping=True,
            n_iter_no_change=30,
            random_state=seed,
        )
    if name == "tabnet":
        from pytorch_tabnet.tab_model import TabNetRegressor

        return TabNetRegressor(
            **parameters,
            seed=seed,
            verbose=0,
            optimizer_params={"lr": 2.0e-2, "weight_decay": 1.0e-5},
        )
    raise ValueError(name)


def _fit(model, name: str, x, y):
    if name == "tabnet":
        model.fit(
            x,
            y,
            max_epochs=250,
            patience=30,
            batch_size=64,
            virtual_batch_size=32,
            drop_last=False,
        )
    else:
        model.fit(x, y)
    return model


def _tune(name, bundle, indices, config, trials, seed):
    inner = GroupKFold(n_splits=config["cross_validation"]["inner_folds"])

    def objective(trial):
        parameters = _parameters(name, trial)
        scores = []
        local = np.arange(len(indices))
        for train_local, validation_local in inner.split(local, groups=bundle.groups[indices]):
            train_indices = indices[train_local]
            validation_indices = indices[validation_local]
            processor = RobustFoldPreprocessor(
                config["preprocessing"]["lower_quantile"],
                config["preprocessing"]["upper_quantile"],
                config["preprocessing"]["epsilon"],
            ).fit(bundle.x[train_indices])
            x_train = processor.transform(bundle.x[train_indices])[0]
            x_validation = processor.transform(bundle.x[validation_indices])[0]
            model = _build(name, parameters, seed + trial.number)
            _fit(model, name, x_train, bundle.y[train_indices])
            prediction = model.predict(x_validation)
            scores.append(mean_euclidean_distance(bundle.y[validation_indices], prediction))
        return float(np.mean(scores))

    study = optuna.create_study(
        direction="minimize",
        sampler=optuna.samplers.TPESampler(seed=seed),
    )
    study.optimize(objective, n_trials=trials, show_progress_bar=False)
    fitted_parameters = _parameters(name, optuna.trial.FixedTrial(study.best_params))
    return fitted_parameters, study.best_value


def _prediction_frame(bundle, indices, prediction, fold=None):
    frame = pd.DataFrame(
        {
            "song_id": bundle.song_ids[indices],
            "target_valence": bundle.y[indices, 0],
            "target_arousal": bundle.y[indices, 1],
            "predicted_valence": prediction[:, 0],
            "predicted_arousal": prediction[:, 1],
        }
    )
    if fold is not None:
        frame["fold"] = fold
    return frame


def run_standard_baselines(config_path: str, models: list[str]) -> dict:
    suite = load_yaml(config_path)
    config = load_yaml(suite["base_config"])
    output = Path(suite["output_dir"])
    output.mkdir(parents=True, exist_ok=True)
    data = config["data"]
    deam = load_prepared_table(data["deam_table"], data["feature_prefix"])
    pmemo = load_prepared_table(data["pmemo_table"], data["feature_prefix"])
    splits = grouped_outer_splits(
        deam.groups,
        config["cross_validation"]["outer_folds"],
        config["cross_validation"]["calibration_fraction"],
        config["cross_validation"]["temperature_fraction"],
        config["cross_validation"]["splitter_seed"],
    )
    results = {}
    for name in models:
        frames = []
        tuning = []
        for split in splits:
            parameters, inner_med = _tune(
                name,
                deam,
                split.fit_indices,
                config,
                suite["search_trials"],
                config["cross_validation"]["splitter_seed"] + split.fold,
            )
            processor = RobustFoldPreprocessor(
                config["preprocessing"]["lower_quantile"],
                config["preprocessing"]["upper_quantile"],
                config["preprocessing"]["epsilon"],
            ).fit(deam.x[split.fit_indices])
            x_train = processor.transform(deam.x[split.fit_indices])[0]
            x_test = processor.transform(deam.x[split.test_indices])[0]
            model = _build(name, parameters, config["training"]["seeds"][0])
            _fit(model, name, x_train, deam.y[split.fit_indices])
            prediction = model.predict(x_test)
            frames.append(_prediction_frame(deam, split.test_indices, prediction, split.fold))
            tuning.append(
                {"fold": split.fold, "parameters": parameters, "inner_med": inner_med}
            )
        oof = pd.concat(frames, ignore_index=True).sort_values("song_id")
        oof.to_parquet(output / f"predictions_deam_{name}.parquet", index=False)

        final = _final_split(deam.groups, config)
        parameters, inner_med = _tune(
            name,
            deam,
            final.fit_indices,
            config,
            suite["search_trials"],
            config["cross_validation"]["splitter_seed"] + 700,
        )
        processor = RobustFoldPreprocessor(
            config["preprocessing"]["lower_quantile"],
            config["preprocessing"]["upper_quantile"],
            config["preprocessing"]["epsilon"],
        ).fit(deam.x[final.fit_indices])
        x_train = processor.transform(deam.x[final.fit_indices])[0]
        x_external = processor.transform(pmemo.x)[0]
        model = _build(name, parameters, config["training"]["seeds"][0])
        _fit(model, name, x_train, deam.y[final.fit_indices])
        external_prediction = model.predict(x_external)
        external = _prediction_frame(
            pmemo, np.arange(len(pmemo.x)), external_prediction
        )
        external.to_parquet(output / f"predictions_pmemo_{name}.parquet", index=False)
        results[name] = {
            "deam_med": mean_euclidean_distance(
                oof[["target_valence", "target_arousal"]].to_numpy(),
                oof[["predicted_valence", "predicted_arousal"]].to_numpy(),
            ),
            "pmemo_med": mean_euclidean_distance(pmemo.y, external_prediction),
            "fold_tuning": tuning,
            "final_tuning": {"parameters": parameters, "inner_med": inner_med},
        }
    write_json(results, output / "standard_baseline_summary.json")
    return results
