from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from .config import load_yaml
from .data.dataset import TorchArrayDataset, load_prepared_table
from .data.preprocessing import RobustFoldPreprocessor
from .data.splits import grouped_outer_splits
from .engine import predict
from .ensemble import moment_match_student_t
from .metrics import mean_euclidean_distance
from .models import RJDCalNet
from .pipeline import _fit_members
from .utils import read_json, resolve_device, write_json


def _models_for_fold(fold: int, config: dict, manifest: dict, checkpoint_dir: Path, device):
    import torch

    models = []
    for seed in config["training"]["seeds"]:
        path = checkpoint_dir / f"fold_{fold}_seed_{seed}.pt"
        if not path.exists():
            raise FileNotFoundError(f"Missing checkpoint: {path}")
        model = RJDCalNet(manifest, config).to(device)
        checkpoint = torch.load(path, map_location=device, weights_only=True)
        model.load_state_dict(checkpoint["model_state"])
        model.eval()
        models.append(model)
    return models


def _ensemble_prediction(models, dataset, config, device):
    members = [
        predict(model, dataset, config["training"]["batch_size"], device) for model in models
    ]
    return moment_match_student_t(members)


def _quadrant(target: np.ndarray) -> np.ndarray:
    values = np.empty(len(target), dtype=object)
    low_v = target[:, 0] < 0.5
    low_a = target[:, 1] < 0.5
    values[low_v & low_a] = "LVLA"
    values[low_v & ~low_a] = "LVHA"
    values[~low_v & low_a] = "HVLA"
    values[~low_v & ~low_a] = "HVHA"
    return values


def run_robustness_suite(path: str) -> list[dict]:
    suite = load_yaml(path)
    config = load_yaml(suite["base_config"])
    run_dir = Path(config["run"]["output_dir"])
    output = Path(suite["output_dir"])
    output.mkdir(parents=True, exist_ok=True)
    data = config["data"]
    bundle = load_prepared_table(data["deam_table"], data["feature_prefix"])
    manifest = read_json(data["feature_manifest"])
    splits = grouped_outer_splits(
        bundle.groups,
        config["cross_validation"]["outer_folds"],
        config["cross_validation"]["calibration_fraction"],
        config["cross_validation"]["temperature_fraction"],
        config["cross_validation"]["splitter_seed"],
    )
    device = resolve_device(config["run"]["device"])
    records = []
    for condition, settings in suite["conditions"].items():
        if condition == "emotion_quadrant":
            predictions_path = run_dir / "predictions_deam_oof.parquet"
            if not predictions_path.exists():
                raise FileNotFoundError(predictions_path)
            frame = pd.read_parquet(predictions_path)
            target = frame[["target_valence", "target_arousal"]].to_numpy()
            prediction = frame[["predicted_valence", "predicted_arousal"]].to_numpy()
            labels = _quadrant(target)
            for level in settings["groups"]:
                selected = labels == level
                records.append(
                    {
                        "condition": condition,
                        "level": level,
                        "med_mean": mean_euclidean_distance(target[selected], prediction[selected]),
                        "med_sd": None,
                    }
                )
            continue
        fold_scores = {str(level): [] for level in settings["levels"]}
        if condition in {"feature_masking", "gaussian_feature_noise"}:
            for split in splits:
                processor = RobustFoldPreprocessor.from_state_dict(
                    read_json(run_dir / f"preprocessor_fold_{split.fold}.json")
                )
                x, missing = processor.transform(bundle.x[split.test_indices])
                models = _models_for_fold(
                    split.fold, config, manifest, run_dir / "checkpoints", device
                )
                for level in settings["levels"]:
                    rng = np.random.default_rng(2026 + split.fold + int(float(level) * 1000))
                    perturbed_x = x.copy()
                    perturbed_missing = missing.copy()
                    if condition == "feature_masking":
                        mask = rng.random(perturbed_x.shape) < float(level)
                        perturbed_x[mask] = 0.0
                        perturbed_missing[mask] = 1.0
                    else:
                        perturbed_x += rng.normal(0.0, float(level), size=perturbed_x.shape).astype(
                            np.float32
                        )
                    dataset = TorchArrayDataset(
                        perturbed_x,
                        perturbed_missing,
                        bundle.y[split.test_indices],
                        bundle.disagreement[split.test_indices],
                        indices=split.test_indices,
                    )
                    prediction = _ensemble_prediction(models, dataset, config, device)
                    fold_scores[str(level)].append(
                        mean_euclidean_distance(
                            bundle.y[split.test_indices], prediction["location"]
                        )
                    )
        elif condition == "training_fraction":
            for split in splits:
                fit_groups = np.unique(bundle.groups[split.fit_indices])
                for level in settings["levels"]:
                    rng = np.random.default_rng(settings["subset_seed"] + split.fold)
                    selected_count = max(2, int(round(len(fit_groups) * float(level))))
                    selected_groups = set(
                        rng.choice(fit_groups, size=selected_count, replace=False).tolist()
                    )
                    selected_indices = split.fit_indices[
                        np.isin(bundle.groups[split.fit_indices], list(selected_groups))
                    ]
                    predictions, _, _ = _fit_members(
                        bundle,
                        selected_indices,
                        {"test": (bundle, split.test_indices)},
                        manifest,
                        config,
                        output / "fraction_checkpoints" / str(level),
                        f"fold_{split.fold}",
                    )
                    fold_scores[str(level)].append(
                        mean_euclidean_distance(
                            bundle.y[split.test_indices], predictions["test"]["location"]
                        )
                    )
        else:
            raise ValueError(f"Unsupported robustness condition: {condition}")
        for level, values in fold_scores.items():
            records.append(
                {
                    "condition": condition,
                    "level": level,
                    "med_mean": float(np.mean(values)),
                    "med_sd": float(np.std(values, ddof=1)),
                    "fold_values": values,
                }
            )
    pd.DataFrame(records).to_csv(output / "rjd_robustness_results.csv", index=False)
    write_json(records, output / "rjd_robustness_results.json")
    return records

