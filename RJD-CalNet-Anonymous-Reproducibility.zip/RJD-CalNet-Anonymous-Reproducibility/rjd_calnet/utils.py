from __future__ import annotations

import hashlib
import json
import os
import platform
import random
import subprocess
from pathlib import Path
from typing import Any

import numpy as np


def seed_everything(seed: int, deterministic: bool = True) -> None:
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch

        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        if deterministic:
            torch.use_deterministic_algorithms(True, warn_only=True)
            torch.backends.cudnn.benchmark = False
    except ImportError:
        pass


def write_json(payload: Any, path: str | Path) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True, ensure_ascii=False)
        handle.write("\n")


def read_json(path: str | Path) -> Any:
    with Path(path).open("r", encoding="utf-8") as handle:
        return json.load(handle)


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def source_tree_hash(root: str | Path) -> str:
    root_path = Path(root)
    digest = hashlib.sha256()
    for path in sorted(root_path.rglob("*")):
        if not path.is_file() or any(part in {".git", "outputs", "data"} for part in path.parts):
            continue
        digest.update(str(path.relative_to(root_path)).encode("utf-8"))
        digest.update(path.read_bytes())
    return digest.hexdigest()


def environment_inventory() -> dict[str, Any]:
    inventory: dict[str, Any] = {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "hostname_recorded": False,
    }
    for name in ("numpy", "pandas", "scipy", "sklearn", "yaml", "torch"):
        try:
            module = __import__(name)
            inventory[name] = getattr(module, "__version__", "unknown")
        except ImportError:
            inventory[name] = None
    if inventory.get("torch") is not None:
        import torch

        inventory["cuda_available"] = torch.cuda.is_available()
        inventory["cuda_version"] = torch.version.cuda
        inventory["gpu_name"] = torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
    try:
        inventory["git_commit"] = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], text=True, stderr=subprocess.DEVNULL
        ).strip()
    except (OSError, subprocess.CalledProcessError):
        inventory["git_commit"] = None
    return inventory


def resolve_device(requested: str):
    import torch

    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(requested)

