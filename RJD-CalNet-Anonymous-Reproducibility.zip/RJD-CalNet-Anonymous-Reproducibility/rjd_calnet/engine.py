from __future__ import annotations

import copy
import math
from collections import defaultdict

import numpy as np

from .losses import joint_student_t_nll, total_training_loss
from .utils import seed_everything


def _loader(dataset, batch_size: int, shuffle: bool, seed: int):
    import torch

    generator = torch.Generator()
    generator.manual_seed(seed)
    return torch.utils.data.DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        generator=generator,
        num_workers=0,
        pin_memory=torch.cuda.is_available(),
    )


def _move(batch: dict, device):
    return {
        key: value.to(device, non_blocking=True) if hasattr(value, "to") else value
        for key, value in batch.items()
    }


def validation_nll(model, loader, device) -> float:
    import torch

    model.eval()
    total = 0.0
    count = 0
    with torch.inference_mode():
        for batch in loader:
            batch = _move(batch, device)
            output = model(batch["x"], batch["missing"])
            loss = joint_student_t_nll(
                batch["y"], output["location"], output["scale"], output["degrees_of_freedom"]
            )
            total += float(loss.item()) * len(batch["x"])
            count += len(batch["x"])
    return total / max(count, 1)


def select_epoch(
    model,
    train_dataset,
    validation_dataset,
    config: dict,
    device,
    seed: int,
) -> tuple[int, list[dict]]:
    import torch

    seed_everything(seed, config["run"]["deterministic"])
    training = config["training"]
    train_loader = _loader(train_dataset, training["batch_size"], True, seed)
    validation_loader = _loader(validation_dataset, training["batch_size"], False, seed)
    model.to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=training["learning_rate"],
        weight_decay=training["weight_decay"],
    )
    total_steps = max(1, training["max_epochs"] * len(train_loader))
    warmup_steps = max(1, training["warmup_epochs"] * len(train_loader))

    def schedule(step):
        if step < warmup_steps:
            return max(step, 1) / warmup_steps
        progress = (step - warmup_steps) / max(total_steps - warmup_steps, 1)
        ratio = training["minimum_learning_rate"] / training["learning_rate"]
        return ratio + 0.5 * (1.0 - ratio) * (1.0 + math.cos(math.pi * progress))

    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, schedule)
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    best_state = None
    best_value = float("inf")
    best_epoch = 1
    without_improvement = 0
    history = []
    for epoch in range(1, training["max_epochs"] + 1):
        model.train()
        sums = defaultdict(float)
        observations = 0
        for batch in train_loader:
            batch = _move(batch, device)
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
                loss, parts = total_training_loss(
                    model, batch, config["loss"], config["corruption"]
                )
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), training["gradient_clip_norm"])
            scaler.step(optimizer)
            scaler.update()
            scheduler.step()
            batch_size = len(batch["x"])
            sums["total"] += float(loss.item()) * batch_size
            for name, value in parts.items():
                sums[name] += float(value.item()) * batch_size
            observations += batch_size
        value = validation_nll(model, validation_loader, device)
        record = {"epoch": epoch, "validation_joint_nll": value}
        record.update({name: total / observations for name, total in sums.items()})
        history.append(record)
        if value < best_value - 1.0e-6:
            best_value = value
            best_epoch = epoch
            best_state = copy.deepcopy(model.state_dict())
            without_improvement = 0
        else:
            without_improvement += 1
        if without_improvement >= training["patience"]:
            break
    if best_state is None:
        raise RuntimeError("Epoch selection did not produce a valid checkpoint")
    model.load_state_dict(best_state)
    return best_epoch, history


def fit_fixed_epochs(model, dataset, config: dict, device, seed: int, epochs: int) -> list[dict]:
    import torch

    seed_everything(seed, config["run"]["deterministic"])
    training = config["training"]
    loader = _loader(dataset, training["batch_size"], True, seed)
    model.to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=training["learning_rate"],
        weight_decay=training["weight_decay"],
    )
    total_steps = max(1, epochs * len(loader))
    warmup_steps = max(1, min(training["warmup_epochs"], epochs) * len(loader))

    def schedule(step):
        if step < warmup_steps:
            return max(step, 1) / warmup_steps
        progress = (step - warmup_steps) / max(total_steps - warmup_steps, 1)
        ratio = training["minimum_learning_rate"] / training["learning_rate"]
        return ratio + 0.5 * (1.0 - ratio) * (1.0 + math.cos(math.pi * progress))

    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, schedule)
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    history = []
    for epoch in range(1, epochs + 1):
        model.train()
        sums = defaultdict(float)
        observations = 0
        for batch in loader:
            batch = _move(batch, device)
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda", enabled=device.type == "cuda"):
                loss, parts = total_training_loss(
                    model, batch, config["loss"], config["corruption"]
                )
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), training["gradient_clip_norm"])
            scaler.step(optimizer)
            scaler.update()
            scheduler.step()
            batch_size = len(batch["x"])
            sums["total"] += float(loss.item()) * batch_size
            for name, value in parts.items():
                sums[name] += float(value.item()) * batch_size
            observations += batch_size
        history.append(
            {"epoch": epoch, **{name: total / observations for name, total in sums.items()}}
        )
    return history


def predict(model, dataset, batch_size: int, device) -> dict[str, np.ndarray]:
    import torch

    loader = _loader(dataset, batch_size, False, 0)
    model.eval()
    collected = defaultdict(list)
    with torch.inference_mode():
        for batch in loader:
            batch = _move(batch, device)
            output = model(batch["x"], batch["missing"])
            for name in (
                "location",
                "scale",
                "covariance",
                "degrees_of_freedom",
                "listener_disagreement",
                "reliability",
                "pooling_weights",
                "routing",
            ):
                collected[name].append(output[name].detach().cpu().numpy())
            collected["index"].append(np.asarray(batch["index"]))
    return {name: np.concatenate(values, axis=0) for name, values in collected.items()}

