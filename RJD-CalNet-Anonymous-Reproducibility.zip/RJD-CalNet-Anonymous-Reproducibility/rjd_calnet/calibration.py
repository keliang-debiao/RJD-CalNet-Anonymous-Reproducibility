from __future__ import annotations

import math

import numpy as np
from scipy.special import gammaln


def squared_mahalanobis(target: np.ndarray, location: np.ndarray, scale: np.ndarray) -> np.ndarray:
    residual = target - location
    solved = np.linalg.solve(scale, residual[..., None])[..., 0]
    return np.sum(residual * solved, axis=-1)


def student_t_nll_numpy(
    target: np.ndarray,
    location: np.ndarray,
    scale: np.ndarray,
    degrees_of_freedom: np.ndarray,
) -> np.ndarray:
    dimension = target.shape[-1]
    residual = target - location
    mahalanobis = squared_mahalanobis(target, location, scale)
    logdet = np.linalg.slogdet(scale)[1]
    df = np.asarray(degrees_of_freedom)
    log_density = (
        gammaln((df + dimension) / 2.0)
        - gammaln(df / 2.0)
        - 0.5 * (logdet + dimension * np.log(df * math.pi))
        - 0.5 * (df + dimension) * np.log1p(mahalanobis / df)
    )
    return -log_density


def fit_temperature(
    target: np.ndarray,
    location: np.ndarray,
    scale: np.ndarray,
    degrees_of_freedom: np.ndarray,
    lower: float = 0.05,
    upper: float = 20.0,
    grid_size: int = 400,
) -> float:
    grid = np.geomspace(lower, upper, grid_size)
    losses = [student_t_nll_numpy(target, location, scale * value, degrees_of_freedom).mean() for value in grid]
    return float(grid[int(np.argmin(losses))])


def conformal_quantile(scores: np.ndarray, alpha: float) -> float:
    values = np.asarray(scores, dtype=np.float64)
    n = len(values)
    if n == 0:
        raise ValueError("Conformal calibration requires at least one score")
    rank = min(n, int(math.ceil((n + 1) * (1.0 - alpha))))
    return float(np.partition(values, rank - 1)[rank - 1])


def fit_conformal_radii(
    target: np.ndarray,
    location: np.ndarray,
    scale: np.ndarray,
    temperature: float,
    nominal_levels: list[float],
) -> dict[str, float]:
    scores = np.sqrt(squared_mahalanobis(target, location, scale * temperature))
    return {
        f"{level:.2f}": conformal_quantile(scores, 1.0 - level)
        for level in nominal_levels
    }


def coverage_and_area(
    target: np.ndarray,
    location: np.ndarray,
    scale: np.ndarray,
    temperature: float,
    radius: float,
) -> tuple[float, float]:
    calibrated_scale = scale * temperature
    radii = np.sqrt(squared_mahalanobis(target, location, calibrated_scale))
    coverage = float(np.mean(radii <= radius))
    determinant = np.linalg.det(calibrated_scale)
    area = math.pi * radius**2 * np.sqrt(np.maximum(determinant, 0.0))
    return coverage, float(np.mean(area))


def calibration_slope(nominal: np.ndarray, empirical: np.ndarray) -> tuple[float, float]:
    design = np.column_stack((np.ones(len(nominal)), nominal))
    intercept, slope = np.linalg.lstsq(design, empirical, rcond=None)[0]
    return float(slope), float(intercept)

