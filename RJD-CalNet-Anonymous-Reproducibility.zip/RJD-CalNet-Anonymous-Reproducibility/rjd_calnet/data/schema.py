from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from typing import Iterable


GROUP_ORDER = ["spectral", "mfcc", "auditory", "voicing", "rhythm", "chroma", "other"]


@dataclass(frozen=True)
class FeatureIdentity:
    column: str
    group: str
    descriptor: str
    functional: str


def _normalize_token(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_") or "unknown"


def assign_group(column: str, patterns: dict[str, str], fallback: str = "other") -> str:
    for group in GROUP_ORDER[:-1]:
        pattern = patterns.get(group)
        if pattern and re.search(pattern, column):
            return group
    return fallback


def split_identity(column: str) -> tuple[str, str]:
    raw = column.removeprefix("feat__")
    parts = [p for p in re.split(r"[;:_\-]+", raw) if p]
    if len(parts) == 1:
        return _normalize_token(parts[0]), "value"
    functional_markers = (
        "mean",
        "std",
        "percentile",
        "quartile",
        "range",
        "slope",
        "peak",
        "segment",
        "uplevel",
        "downlevel",
        "linreg",
        "qreg",
    )
    split_at = len(parts) - 1
    for index, part in enumerate(parts):
        if any(marker in part.lower() for marker in functional_markers):
            split_at = index
            break
    descriptor = _normalize_token("_".join(parts[:split_at]) or parts[0])
    functional = _normalize_token("_".join(parts[split_at:]))
    return descriptor, functional


def build_feature_identities(
    columns: Iterable[str], patterns: dict[str, str], fallback: str = "other"
) -> list[FeatureIdentity]:
    identities = []
    for column in columns:
        descriptor, functional = split_identity(column)
        identities.append(
            FeatureIdentity(
                column=column,
                group=assign_group(column, patterns, fallback),
                descriptor=descriptor,
                functional=functional,
            )
        )
    return identities


def encode_identities(identities: list[FeatureIdentity]) -> dict:
    descriptor_vocab = {value: i for i, value in enumerate(sorted({x.descriptor for x in identities}))}
    functional_vocab = {value: i for i, value in enumerate(sorted({x.functional for x in identities}))}
    group_vocab = {value: i for i, value in enumerate(GROUP_ORDER)}
    records = []
    for item in identities:
        record = asdict(item)
        record.update(
            descriptor_id=descriptor_vocab[item.descriptor],
            functional_id=functional_vocab[item.functional],
            group_id=group_vocab[item.group],
        )
        records.append(record)
    return {
        "group_order": GROUP_ORDER,
        "descriptor_vocab": descriptor_vocab,
        "functional_vocab": functional_vocab,
        "features": records,
    }

