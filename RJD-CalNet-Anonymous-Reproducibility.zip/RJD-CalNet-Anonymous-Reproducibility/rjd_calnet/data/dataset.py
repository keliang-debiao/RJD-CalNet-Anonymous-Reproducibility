from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class ArrayBundle:
    song_ids: np.ndarray
    groups: np.ndarray
    x: np.ndarray
    y: np.ndarray
    disagreement: np.ndarray


def load_prepared_table(path: str, feature_prefix: str = "feat__") -> ArrayBundle:
    import pandas as pd

    table = pd.read_parquet(path)
    feature_columns = [column for column in table.columns if column.startswith(feature_prefix)]
    if not feature_columns:
        raise ValueError(f"No feature columns beginning with {feature_prefix!r} were found")
    required = [
        "song_id",
        "source_group",
        "valence_mean",
        "arousal_mean",
        "valence_sd",
        "arousal_sd",
    ]
    missing = [column for column in required if column not in table]
    if missing:
        raise ValueError(f"Prepared table is missing required columns: {missing}")
    return ArrayBundle(
        song_ids=table["song_id"].astype(str).to_numpy(),
        groups=table["source_group"].astype(str).to_numpy(),
        x=table[feature_columns].to_numpy(dtype=np.float32),
        y=table[["valence_mean", "arousal_mean"]].to_numpy(dtype=np.float32),
        disagreement=table[["valence_sd", "arousal_sd"]].to_numpy(dtype=np.float32),
    )


class TorchArrayDataset:
    def __init__(self, x, missing, y=None, disagreement=None, indices=None):
        import torch

        self.x = torch.as_tensor(x, dtype=torch.float32)
        self.missing = torch.as_tensor(missing, dtype=torch.float32)
        self.y = None if y is None else torch.as_tensor(y, dtype=torch.float32)
        self.disagreement = (
            None if disagreement is None else torch.as_tensor(disagreement, dtype=torch.float32)
        )
        self.indices = np.arange(len(x)) if indices is None else np.asarray(indices)

    def __len__(self):
        return len(self.x)

    def __getitem__(self, index):
        item = {"x": self.x[index], "missing": self.missing[index], "index": self.indices[index]}
        if self.y is not None:
            item["y"] = self.y[index]
        if self.disagreement is not None:
            item["disagreement"] = self.disagreement[index]
        return item

