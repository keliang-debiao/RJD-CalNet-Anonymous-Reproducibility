"""Data schema, preprocessing, and split utilities."""

