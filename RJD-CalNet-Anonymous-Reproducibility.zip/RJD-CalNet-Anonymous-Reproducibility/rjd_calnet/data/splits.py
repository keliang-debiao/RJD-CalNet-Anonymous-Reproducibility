from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sklearn.model_selection import GroupKFold, GroupShuffleSplit


@dataclass(frozen=True)
class OuterSplit:
    fold: int
    fit_indices: np.ndarray
    temperature_indices: np.ndarray
    conformal_indices: np.ndarray
    test_indices: np.ndarray


def _assert_disjoint(*arrays: np.ndarray) -> None:
    sets = [set(map(int, array.tolist())) for array in arrays]
    for left in range(len(sets)):
        for right in range(left + 1, len(sets)):
            if sets[left].intersection(sets[right]):
                raise AssertionError("Split indices overlap")


def _assert_group_disjoint(groups: np.ndarray, *arrays: np.ndarray) -> None:
    group_sets = [set(groups[array].tolist()) for array in arrays]
    for left in range(len(group_sets)):
        for right in range(left + 1, len(group_sets)):
            if group_sets[left].intersection(group_sets[right]):
                raise AssertionError("A source group crosses a split boundary")


def grouped_outer_splits(
    groups: np.ndarray,
    n_splits: int = 5,
    calibration_fraction: float = 0.15,
    temperature_fraction: float = 0.05,
    seed: int = 2026,
) -> list[OuterSplit]:
    groups = np.asarray(groups)
    indices = np.arange(len(groups))
    splitter = GroupKFold(n_splits=n_splits)
    results: list[OuterSplit] = []
    relative_temperature = temperature_fraction / calibration_fraction
    for fold, (outer_train, outer_test) in enumerate(splitter.split(indices, groups=groups), start=1):
        reserve_splitter = GroupShuffleSplit(
            n_splits=1, test_size=calibration_fraction, random_state=seed + fold
        )
        fit_local, reserve_local = next(
            reserve_splitter.split(outer_train, groups=groups[outer_train])
        )
        fit_indices = outer_train[fit_local]
        reserve_indices = outer_train[reserve_local]
        temp_splitter = GroupShuffleSplit(
            n_splits=1, test_size=relative_temperature, random_state=seed + 100 + fold
        )
        conformal_local, temperature_local = next(
            temp_splitter.split(reserve_indices, groups=groups[reserve_indices])
        )
        temperature_indices = reserve_indices[temperature_local]
        conformal_indices = reserve_indices[conformal_local]
        _assert_disjoint(fit_indices, temperature_indices, conformal_indices, outer_test)
        _assert_group_disjoint(
            groups, fit_indices, temperature_indices, conformal_indices, outer_test
        )
        results.append(
            OuterSplit(
                fold=fold,
                fit_indices=fit_indices,
                temperature_indices=temperature_indices,
                conformal_indices=conformal_indices,
                test_indices=outer_test,
            )
        )
    return results

