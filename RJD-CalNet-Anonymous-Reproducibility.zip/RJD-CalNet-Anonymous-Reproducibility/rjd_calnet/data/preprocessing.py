from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class RobustFoldPreprocessor:
    lower_quantile: float = 0.005
    upper_quantile: float = 0.995
    epsilon: float = 1.0e-6

    def fit(self, x: np.ndarray) -> "RobustFoldPreprocessor":
        values = np.asarray(x, dtype=np.float64).copy()
        values[~np.isfinite(values)] = np.nan
        self.lower_ = np.nanquantile(values, self.lower_quantile, axis=0)
        self.upper_ = np.nanquantile(values, self.upper_quantile, axis=0)
        clipped = np.clip(values, self.lower_, self.upper_)
        self.median_ = np.nanmedian(clipped, axis=0)
        q25 = np.nanquantile(clipped, 0.25, axis=0)
        q75 = np.nanquantile(clipped, 0.75, axis=0)
        self.iqr_ = q75 - q25
        invalid = ~np.isfinite(self.median_)
        self.median_[invalid] = 0.0
        self.iqr_[~np.isfinite(self.iqr_)] = 0.0
        self.n_features_in_ = values.shape[1]
        return self

    def transform(self, x: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        if not hasattr(self, "median_"):
            raise RuntimeError("Preprocessor must be fitted before transform")
        values = np.asarray(x, dtype=np.float64).copy()
        if values.shape[1] != self.n_features_in_:
            raise ValueError("Feature count differs from the fitted training partition")
        missing = ~np.isfinite(values)
        values[missing] = np.nan
        values = np.clip(values, self.lower_, self.upper_)
        values = np.where(np.isnan(values), self.median_, values)
        scaled = (values - self.median_) / (self.iqr_ + self.epsilon)
        return scaled.astype(np.float32), missing.astype(np.float32)

    def fit_transform(self, x: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        return self.fit(x).transform(x)

    def state_dict(self) -> dict[str, list | float | int]:
        return {
            "lower_quantile": self.lower_quantile,
            "upper_quantile": self.upper_quantile,
            "epsilon": self.epsilon,
            "lower": self.lower_.tolist(),
            "upper": self.upper_.tolist(),
            "median": self.median_.tolist(),
            "iqr": self.iqr_.tolist(),
            "n_features": self.n_features_in_,
        }

    @classmethod
    def from_state_dict(cls, state: dict) -> "RobustFoldPreprocessor":
        obj = cls(state["lower_quantile"], state["upper_quantile"], state["epsilon"])
        obj.lower_ = np.asarray(state["lower"], dtype=np.float64)
        obj.upper_ = np.asarray(state["upper"], dtype=np.float64)
        obj.median_ = np.asarray(state["median"], dtype=np.float64)
        obj.iqr_ = np.asarray(state["iqr"], dtype=np.float64)
        obj.n_features_in_ = int(state["n_features"])
        return obj

