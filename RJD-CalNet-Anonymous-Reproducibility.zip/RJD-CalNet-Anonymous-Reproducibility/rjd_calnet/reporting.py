from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from .metrics import mean_euclidean_distance
from .statistics import holm_adjust, paired_comparison
from .utils import write_json


def _euclidean_errors(frame: pd.DataFrame) -> np.ndarray:
    target = frame[["target_valence", "target_arousal"]].to_numpy(dtype=np.float64)
    prediction = frame[["predicted_valence", "predicted_arousal"]].to_numpy(dtype=np.float64)
    return np.linalg.norm(target - prediction, axis=1)


def run_paired_statistics(config: dict) -> list[dict]:
    run_dir = Path(config["run"]["output_dir"])
    proposed_paths = {
        "DEAM": run_dir / "predictions_deam_oof.parquet",
        "PMEmo": run_dir / "predictions_pmemo_frozen.parquet",
    }
    baseline_dir = run_dir.parent / "baselines"
    comparisons = []
    for dataset, proposed_path in proposed_paths.items():
        if not proposed_path.exists():
            raise FileNotFoundError(f"Missing proposed prediction file: {proposed_path}")
        proposed = pd.read_parquet(proposed_path).sort_values("song_id")
        family = []
        for model in ("dynatab", "tabm", "xgboost"):
            baseline_path = baseline_dir / f"predictions_{dataset.lower()}_{model}.parquet"
            if not baseline_path.exists():
                continue
            baseline = pd.read_parquet(baseline_path).sort_values("song_id")
            merged = proposed.merge(
                baseline,
                on="song_id",
                suffixes=("_rjd", "_baseline"),
                validate="one_to_one",
            )
            proposed_frame = pd.DataFrame(
                {
                    "target_valence": merged["target_valence_rjd"],
                    "target_arousal": merged["target_arousal_rjd"],
                    "predicted_valence": merged["predicted_valence_rjd"],
                    "predicted_arousal": merged["predicted_arousal_rjd"],
                }
            )
            baseline_frame = pd.DataFrame(
                {
                    "target_valence": merged["target_valence_rjd"],
                    "target_arousal": merged["target_arousal_rjd"],
                    "predicted_valence": merged["predicted_valence_baseline"],
                    "predicted_arousal": merged["predicted_arousal_baseline"],
                }
            )
            result = paired_comparison(
                _euclidean_errors(proposed_frame),
                _euclidean_errors(baseline_frame),
                resamples=config["evaluation"]["bootstrap_resamples"],
                seed=config["evaluation"]["bootstrap_seed"],
            )
            result.update(dataset=dataset, comparator=model)
            family.append(result)
        adjusted = holm_adjust([item["raw_p"] for item in family]) if family else []
        for item, value in zip(family, adjusted):
            item["holm_p"] = value
            comparisons.append(item)
    if not comparisons:
        raise FileNotFoundError(
            f"No aligned baseline prediction files were found under {baseline_dir}"
        )
    write_json(comparisons, run_dir / "paired_tests.json")
    pd.DataFrame(comparisons).to_csv(run_dir / "paired_tests.csv", index=False)
    return comparisons


def summarize_run(run_dir: str | Path) -> dict:
    directory = Path(run_dir)
    summary: dict = {"run_dir": str(directory)}
    for name in ("data_audit", "metrics_internal", "metrics_external", "calibration"):
        path = directory / f"{name}.json"
        if path.exists():
            with path.open("r", encoding="utf-8") as handle:
                summary[name] = json.load(handle)
    internal_predictions = directory / "predictions_deam_oof.parquet"
    external_predictions = directory / "predictions_pmemo_frozen.parquet"
    if internal_predictions.exists():
        frame = pd.read_parquet(internal_predictions)
        summary["deam_prediction_rows"] = len(frame)
        summary["deam_med_recomputed"] = mean_euclidean_distance(
            frame[["target_valence", "target_arousal"]].to_numpy(),
            frame[["predicted_valence", "predicted_arousal"]].to_numpy(),
        )
    if external_predictions.exists():
        frame = pd.read_parquet(external_predictions)
        summary["pmemo_prediction_rows"] = len(frame)
        summary["pmemo_med_recomputed"] = mean_euclidean_distance(
            frame[["target_valence", "target_arousal"]].to_numpy(),
            frame[["predicted_valence", "predicted_arousal"]].to_numpy(),
        )
    write_json(summary, directory / "run_summary.json")
    return summary

