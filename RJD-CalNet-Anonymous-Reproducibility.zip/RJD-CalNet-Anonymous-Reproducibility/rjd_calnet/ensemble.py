from __future__ import annotations

import numpy as np


def moment_match_student_t(members: list[dict[str, np.ndarray]]) -> dict[str, np.ndarray]:
    if not members:
        raise ValueError("At least one ensemble member is required")
    locations = np.stack([member["location"] for member in members], axis=0)
    scales = np.stack([member["scale"] for member in members], axis=0)
    dfs = np.stack([member["degrees_of_freedom"] for member in members], axis=0)
    covariances = scales * (dfs / (dfs - 2.0))[..., None, None]
    mean_location = locations.mean(axis=0)
    centered = locations - mean_location[None, ...]
    between = np.einsum("snk,snl->snkl", centered, centered).mean(axis=0)
    mean_covariance = covariances.mean(axis=0) + between
    median_df = np.median(dfs, axis=0)
    matched_scale = mean_covariance * ((median_df - 2.0) / median_df)[..., None, None]
    result = {
        "location": mean_location,
        "scale": matched_scale,
        "covariance": mean_covariance,
        "degrees_of_freedom": median_df,
    }
    if "listener_disagreement" in members[0]:
        result["listener_disagreement"] = np.stack(
            [member["listener_disagreement"] for member in members], axis=0
        ).mean(axis=0)
    return result

